package controller;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import model.DBEKMEANS;
public class dashboardController {
	List<Integer> asset_code;
	int count = 0;
	String filter;
	String query;
	String query2;
	String query3;
	
	public dashboardController(){
		asset_code = new ArrayList<Integer>();
		filter = view.ASSETVIEW.dashFilterCB.getSelectedItem().toString();
	}
	
	public void kConsistency(){
		DBEKMEANS.TestConnection();
		asset_code.clear();
		count = 0;
		try{
			if(filter.equals(""))
			query = "SELECT F.factor_id, cluster FROM tbl_cluster C join tbl_cluster_detail CD ON C.cluster_id = CD.cluster_id"
					+ " join tbl_factor F on CD.factor_id = F.factor_id"
					+ " join tbl_asset A on A.asset_code = F.asset_code"
					+ " join tbl_subcategory S on S.subcategory_id = A.asset_category"
					+ " join tbl_category CT on CT.category_id = S.category_id" +
					" WHERE isEnhanced = 0" +
					" Group by factor_id, cluster";
			else 
				query = "SELECT F.factor_id, cluster FROM tbl_cluster C join tbl_cluster_detail CD ON C.cluster_id = CD.cluster_id"
						+ " join tbl_factor F on CD.factor_id = F.factor_id"
						+ " join tbl_asset A on A.asset_code = F.asset_code"
						+ " join tbl_subcategory S on S.subcategory_id = A.asset_category"
						+ " join tbl_category CT on CT.category_id = S.category_id" +
						" WHERE isEnhanced = 0 and category_name = '"+ filter + "' " +
						" Group by factor_id, cluster";
			
			System.out.println(query);
			PreparedStatement ps = DBEKMEANS.conn.prepareStatement(query);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()){
				int id = rs.getInt("factor_id");
				if(asset_code.contains(id)){
					count++;
				}
				else asset_code.add(id);
			}
			
			rs.close();
			ps.close();
			DBEKMEANS.conn.close();
			
			System.out.println(asset_code.size());
			System.out.println(count);
			double percent = (double)((asset_code.size() - count)/(double)asset_code.size()) * 100;
			System.out.println(percent);
			
			DecimalFormat df = new DecimalFormat("0.00");
			view.ASSETVIEW.kConValue.setText(df.format(percent)  + " %");
			
			
		}
		catch(Exception E){
			E.printStackTrace();
		}
	}
	
	public void eConsistency(){
		DBEKMEANS.TestConnection();
		asset_code.clear();
		count = 0;
		try{
			if(filter.equals(""))
				query2 = "SELECT F.factor_id, cluster FROM tbl_cluster C join tbl_cluster_detail CD ON C.cluster_id = CD.cluster_id"
						+ " join tbl_factor F on CD.factor_id = F.factor_id"
						+ " join tbl_asset A on A.asset_code = F.asset_code"
						+ " join tbl_subcategory S on S.subcategory_id = A.asset_category"
						+ " join tbl_category CT on CT.category_id = S.category_id" +
						" WHERE isEnhanced = 1" +
						" Group by factor_id, cluster";
				else 
					query2 = "SELECT F.factor_id, cluster FROM tbl_cluster C join tbl_cluster_detail CD ON C.cluster_id = CD.cluster_id"
							+ " join tbl_factor F on CD.factor_id = F.factor_id"
							+ " join tbl_asset A on A.asset_code = F.asset_code"
							+ " join tbl_subcategory S on S.subcategory_id = A.asset_category"
							+ " join tbl_category CT on CT.category_id = S.category_id" +
							" WHERE isEnhanced = 1 and category_name = '"+ filter + "' " +
							" Group by factor_id, cluster";
			PreparedStatement ps = DBEKMEANS.conn.prepareStatement(query2);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()){
				int id = rs.getInt("factor_id");
				if(asset_code.contains(id)){
					count++;
				}
				else asset_code.add(id);
			}
			
			rs.close();
			ps.close();
			DBEKMEANS.conn.close();
			
			System.out.println(asset_code.size());
			System.out.println(count);
			double percent = (double)((asset_code.size() - count)/(double)asset_code.size()) * 100;
			System.out.println(percent);
			DecimalFormat df = new DecimalFormat("0.00");
			view.ASSETVIEW.eConValue.setText(df.format(percent)  + " %");
			
			
		}
		catch(Exception E){
			E.printStackTrace();
		}
	}
	
	public void avgStat(){
		DBEKMEANS.TestConnection();
		
		try{
			if(filter.equals("")){
  			  query3 = "SELECT summary.isEnhanced, avg(summary.run_time) as run_time, avg(summary.iteration) as iteration, avg(summary.asset) as asset FROM ( " +
  					"SELECT CD.cluster_id, isEnhanced, avg(run_time) as run_time, avg(iteration) as iteration, count(F.factor_id) as asset from tbl_cluster C " +
					  "join tbl_cluster_detail CD on C.cluster_id = CD.cluster_id " +
					  "join tbl_factor F on CD.factor_id = F.factor_id " +
					  "join tbl_asset A on A.asset_code = F.asset_code " +
					  "join tbl_subcategory S on S.subcategory_id = A.asset_category "+
					  "join tbl_category CT on S.category_id = CT.category_id " +
					  "group by isEnhanced, CD.cluster_id " +
                    ") summary group by summary.isEnhanced" ;
  		  }
  		  
  		  else{
  			  query3 = "SELECT summary.isEnhanced, avg(summary.run_time) as run_time, avg(summary.iteration) as iteration, avg(summary.asset) as asset FROM ( "
  			  		+ "SELECT CD.cluster_id, isEnhanced, avg(run_time) as run_time, avg(iteration) as iteration, count(F.factor_id) as asset from tbl_cluster C " +
  					  "join tbl_cluster_detail CD on C.cluster_id = CD.cluster_id " +
  					  "join tbl_factor F on CD.factor_id = F.factor_id " + 
  					  "join tbl_asset A on A.asset_code = F.asset_code " +
  					  "join tbl_subcategory S on S.subcategory_id = A.asset_category " +
  					  "join tbl_category CT on S.category_id = CT.category_id " +
  					  "WHERE CT.category_name = '" + filter + "'"
  					  		+ " group by isEnhanced"
  					  		+ " ) summary group by summary.isEnhanced";
  		  }
			
			System.out.println(query3);
			PreparedStatement ps2 =  DBEKMEANS.conn.prepareStatement(query3);
			
			ResultSet rs2 = ps2.executeQuery();
			
			
				view.ASSETVIEW.eAveIterValue.setText("0.00");
				view.ASSETVIEW.eAveSpeedValue.setText("0.00");
				view.ASSETVIEW.kAveIterValue.setText("0.00");
				view.ASSETVIEW.kAveSpeedValue.setText("0.00");
				
			
			while(rs2.next()){
				DecimalFormat df = new DecimalFormat("0.00");
				
				int isEnhanced = rs2.getInt("isEnhanced");
				String iteration = df.format(rs2.getFloat("iteration"));
				String runtime = df.format(rs2.getFloat("run_time"));
				System.out.println(iteration);
				
				if(isEnhanced == 1){
					view.ASSETVIEW.eAveIterValue.setText(iteration);
					view.ASSETVIEW.eAveSpeedValue.setText(runtime);
				}
				else if(isEnhanced == 0) {
					view.ASSETVIEW.kAveIterValue.setText(iteration);
					view.ASSETVIEW.kAveSpeedValue.setText(runtime);
				}
				
			}
			
		
		}
		catch(Exception E){
			E.printStackTrace();
		}
	}
}
