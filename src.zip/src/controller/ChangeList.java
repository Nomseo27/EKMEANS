package controller;

import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import model.DBEKMEANS;

public class ChangeList implements FocusListener {

	@Override
	public void focusGained(FocusEvent e) {
		// TODO Auto-generated method stub
		
		
		
		
		
		if(e.getSource() == view.ASSETVIEW.f_categoryField){
			view.ASSETVIEW.f_categoryField.removeItemListener(view.ASSETVIEW.CB);
			DBEKMEANS.TestConnection();
			try{
				String categoryList = "Select category_name from tbl_category where deleted = 0";
				PreparedStatement select2 =  DBEKMEANS.conn.prepareStatement(categoryList);
			
				ResultSet rs2 = select2.executeQuery();
				view.ASSETVIEW.f_categoryField.removeAllItems();
				view.ASSETVIEW.f_categoryField.addItem("");
				
				while(rs2.next()){
					String ctgry = rs2.getString("category_name");
					view.ASSETVIEW.f_categoryField.addItem(ctgry);
					System.out.println(ctgry);
				}
				rs2.close();
				select2.close();
				DBEKMEANS.conn.close();
				view.ASSETVIEW.f_categoryField.addItemListener(view.ASSETVIEW.CB);
			}
			catch(Exception E){
				E.printStackTrace();
			}
			
			
		}
		
		else if(e.getSource() == view.ASSETVIEW.CB_category){
			DBEKMEANS.TestConnection();
			try{
				String categoryList = "Select category_name from tbl_category where deleted = 0";
				PreparedStatement select2 =  DBEKMEANS.conn.prepareStatement(categoryList);
			
				ResultSet rs2 = select2.executeQuery();

				view.ASSETVIEW.CB_category.removeAllItems();
				view.ASSETVIEW.CB_category.addItem("");
				while(rs2.next()){
					String ctgry = rs2.getString("category_name");
					view.ASSETVIEW.CB_category.addItem(ctgry);
					System.out.println(ctgry);
				}
				rs2.close();
				select2.close();
				DBEKMEANS.conn.close();
			}
			catch(Exception E){
				E.printStackTrace();
			}
			
			
		}
		
		else if(e.getSource() == view.ASSETVIEW.f_assetCodeField || e.getSource() == view.ASSETVIEW.listAsset){
			view.ASSETVIEW.f_assetCodeField.removeItemListener(view.ASSETVIEW.CB);
			DBEKMEANS.TestConnection();
			try{
				String categoryList = "Select asset_code from tbl_asset where disposed is null";
				PreparedStatement select2 =  DBEKMEANS.conn.prepareStatement(categoryList);
			
				ResultSet rs2 = select2.executeQuery();

				view.ASSETVIEW.f_assetCodeField.removeAllItems();
				view.ASSETVIEW.f_assetCodeField.addItem("");
				view.ASSETVIEW.listAsset.removeAllItems();
				view.ASSETVIEW.listAsset.addItem("");
				while(rs2.next()){
					String asset = rs2.getString("asset_code");
					view.ASSETVIEW.f_assetCodeField.addItem(asset);
					view.ASSETVIEW.listAsset.addItem(asset);
					System.out.println(asset);
				}
				rs2.close();
				select2.close();
				DBEKMEANS.conn.close();
				view.ASSETVIEW.f_assetCodeField.addItemListener(view.ASSETVIEW.CB);
			}
			catch(Exception E){
				E.printStackTrace();
			}
			
			
		}
		
		else if(e.getSource() == view.ASSETVIEW.k_subCategoryField){
			DBEKMEANS.TestConnection();
			try{
				String subcategoryList = "Select category_name from tbl_category";
				PreparedStatement select2 =  DBEKMEANS.conn.prepareStatement(subcategoryList);
			
				ResultSet rs2 = select2.executeQuery();

				view.ASSETVIEW.k_subCategoryField.removeAllItems();
				view.ASSETVIEW.k_subCategoryField.addItem("");
				while(rs2.next()){
					String subctgry = rs2.getString("category_name");
					view.ASSETVIEW.k_subCategoryField.addItem(subctgry);
					System.out.println(subctgry);
				}
				rs2.close();
				select2.close();
				DBEKMEANS.conn.close();
			}
			catch(Exception E){
				E.printStackTrace();
			}
		}
		
		else if(e.getSource() == view.ASSETVIEW.Filter){
			DBEKMEANS.TestConnection();
			view.ASSETVIEW.Filter.removeItemListener(view.ASSETVIEW.CB);
			try{
				String subcategoryList = "Select category_name from tbl_category";
				PreparedStatement select2 =  DBEKMEANS.conn.prepareStatement(subcategoryList);
			
				ResultSet rs2 = select2.executeQuery();

				view.ASSETVIEW.Filter.removeAllItems();
				view.ASSETVIEW.Filter.addItem("");
				while(rs2.next()){
					String subctgry = rs2.getString("category_name");
					view.ASSETVIEW.Filter.addItem(subctgry);
					System.out.println(subctgry);
				}
				rs2.close();
				select2.close();
				DBEKMEANS.conn.close();
				view.ASSETVIEW.Filter.addItemListener(view.ASSETVIEW.CB);
			}
			catch(Exception E){
				E.printStackTrace();
			}
		}
		
		else if(e.getSource() == view.ASSETVIEW.dashFilterCB){
			DBEKMEANS.TestConnection();
			view.ASSETVIEW.dashFilterCB.removeItemListener(view.ASSETVIEW.CB);
			try{
				String subcategoryList = "Select category_name from tbl_category";
				PreparedStatement select2 =  DBEKMEANS.conn.prepareStatement(subcategoryList);
			
				ResultSet rs2 = select2.executeQuery();

				view.ASSETVIEW.dashFilterCB.removeAllItems();
				view.ASSETVIEW.dashFilterCB.addItem("");
				while(rs2.next()){
					String subctgry = rs2.getString("category_name");
					view.ASSETVIEW.dashFilterCB.addItem(subctgry);
					System.out.println(subctgry);
				}
				rs2.close();
				select2.close();
				DBEKMEANS.conn.close();
				view.ASSETVIEW.dashFilterCB.addItemListener(view.ASSETVIEW.CB);
			}
			catch(Exception E){
				E.printStackTrace();
			}
		}
		
		else if(e.getSource() == view.ASSETVIEW.salvageValueField){
			view.ASSETVIEW.salvageValueField.setValue(((Number)view.ASSETVIEW.acqValueField.getValue()).doubleValue() * 0.05);
		}
		
		
		
	}

	@Override
	public void focusLost(FocusEvent arg0) {
		// TODO Auto-generated method stub

	}

}
