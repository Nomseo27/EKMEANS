package controller;

import java.awt.BorderLayout;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel; 
import org.jfree.chart.JFreeChart; 
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset; 
import org.jfree.data.category.DefaultCategoryDataset; 

import model.DBEKMEANS;

public class chartController {
	List<String> cluster_name;
	List<Integer> cluster_id;
	public static ChartPanel chartPanel;
	
	String filter;
	String selectStat;
	
	public chartController(){
	      cluster_name =  new ArrayList<String>();
	      cluster_id =  new ArrayList<Integer>();
	      filter = view.ASSETVIEW.dashFilterCB.getSelectedItem().toString();
	      
	      JFreeChart barChart = ChartFactory.createBarChart(
	         "Clustering Iteration, Speed and Number of Fixed Assets",           
	         "Clustering",            
	         "Number",            
	         createDataset(),          
	         PlotOrientation.VERTICAL,           
	         true, true, false);
	         
	      chartPanel = new ChartPanel( barChart );
	      view.ASSETVIEW.dashBoardCenter.add(chartPanel, BorderLayout.CENTER);
	}
	
	private CategoryDataset createDataset( ){
		cluster_id.clear();
		cluster_name.clear();
		
		if(filter.equals("")){
			cluster_name.add("KMEANS");
			cluster_name.add("EKMEANS");
			cluster_id.add(0);
			cluster_id.add(1);
			
			
		}
		else{
			cluster_name.add("KMEANS - " + filter);
			cluster_name.add("EKMEANS - " + filter);
			cluster_id.add(0);
			cluster_id.add(1);
		}
	      final String speed = "Speed";        
	      final String iteration = "Iteration";        
	      final String number = "Number of Fixed Assets";     
	      final DefaultCategoryDataset dataset = 
	      new DefaultCategoryDataset( );  
	      
	      for(int x = 0; x < cluster_id.size(); x++){
	    	  DBEKMEANS.TestConnection();
	    	  try{
	    		  
	    		  if(filter.equals("")){
	    			  selectStat = "SELECT avg(run_time) as run_time, avg(iteration) as iteration, avg(F.factor_id) as asset from tbl_cluster C " +
	    					  "join tbl_cluster_detail CD on C.cluster_id = CD.cluster_id " +
	    					  "join tbl_factor F on CD.factor_id = F.factor_id " + 
	    					  "join tbl_asset A on A.asset_code = F.asset_code " +
	    					  "join tbl_subcategory S on S.subcategory_id = A.asset_category " +
	    					  "join tbl_category CT on S.category_id = CT.category_id " +
	    					  "WHERE isEnhanced = " + cluster_id.get(x);
	    		  }
	    		  
	    		  else{
	    			  selectStat = "SELECT avg(run_time) as run_time, avg(iteration) as iteration, avg(F.factor_id) as asset from tbl_cluster C " +
	    					  "join tbl_cluster_detail CD on C.cluster_id = CD.cluster_id " +
	    					  "join tbl_factor F on CD.factor_id = F.factor_id " + 
	    					  "join tbl_asset A on A.asset_code = F.asset_code " +
	    					  "join tbl_subcategory S on S.subcategory_id = A.asset_category " +
	    					  "join tbl_category CT on S.category_id = CT.category_id " +
	    					  "WHERE isEnhanced = " + cluster_id.get(x) + " "
	    					   + " and CT.category_name = '" + filter + "'";
	    		  }
	    		  PreparedStatement stat = DBEKMEANS.conn.prepareStatement(selectStat);
	    		  ResultSet stats = stat.executeQuery();
	    		  
	    		  while(stats.next()){
	    			  int runtime = stats.getInt("run_time");
	    			  int iterations = stats.getInt("iteration");
	    			  int numbers = stats.getInt("asset");
	    					  
	    			  dataset.addValue(runtime, speed, cluster_name.get(x));
	    			  dataset.addValue(iterations, iteration, cluster_name.get(x));
	    			  dataset.addValue(numbers, number, cluster_name.get(x));
	    			  
	    			  System.out.println(runtime + " " + iterations + " " + numbers);
	    			  
	    			  
	    		  }
	    		  
	    		  stats.close();
	    		  stat.close();
	    		  DBEKMEANS.conn.close();
	    	  }
	    	  catch(Exception E){
	    		  E.printStackTrace();
	    	  }
	      }
	      return dataset; 
	}
}
