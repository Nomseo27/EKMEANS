package controller;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Date;
import java.util.Random;

import javax.swing.SwingWorker;

import eKMEANS.EKMEANS;
import model.DBEKMEANS;

public class Cluster extends SwingWorker<String, Object>{
	long e_time;
	long k_time;
	int e_iteration;
	int k_iteration;
	int cluster_id = 0;
	int scId = 0;

	//prepare indeterminate loading
	view.Loading load;
	
	protected String doInBackground() {
     
    	//prepare indeterminate loading
    	load = new view.Loading();
    	load.progressbar.setIndeterminate(true);
    	
    	//Select sub category ID needed for clustering
    	String category = view.ASSETVIEW.k_subCategoryField.getSelectedItem().toString();
    	String selectCategoryID = "SELECT C.category_id FROM tbl_asset A join tbl_subcategory S on A.asset_category = S.subcategory_id "
    			+ " join tbl_category C on S.category_id = C.category_id "
    			+ " WHERE C.category_name = ?";
    	
    	DBEKMEANS.TestConnection();
    	PreparedStatement psCID;
    	
		try {
			psCID = DBEKMEANS.conn.prepareStatement(selectCategoryID);
			psCID.setString(1, category);
	    	ResultSet rsCID = psCID.executeQuery();
	    	int subID = 0;
	    	if(rsCID.next()){
	    		subID = rsCID.getInt("category_id");
	    		
	    	}
	    	scId = subID;
	    	rsCID.close();
	    	psCID.close();
	    	DBEKMEANS.conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	// end of selecting sub category 
    	
    	
		DBEKMEANS.TestConnection();
		
		//KMEANS ALGORITHM 
		EKMEANS example = new EKMEANS();
		boolean flag = false;
		int iteration = 1;
		
		//initialize variable of the package
		example.initialize();
	
		try{
			String sql = "SELECT tbl_asset.asset_code, usage_factor, age_factor, acq_date, service_life FROM tbl_asset join tbl_factor on tbl_asset.asset_code = tbl_factor.asset_code "
					+ " join tbl_subcategory S on S.subcategory_id = tbl_asset.asset_category"
					+ " join tbl_category C on C.category_id = S.category_id"
					+ " WHERE disposed IS NULL AND C.category_id = ? order by tbl_asset.asset_code";
			PreparedStatement select = DBEKMEANS.conn.prepareStatement(sql);
			
			select.setInt(1, scId);
			
			ResultSet rs = select.executeQuery();
			while(rs.next()){
				
				Date acqDate = rs.getDate("acq_date");
				int life = rs.getInt("service_life");
				//gets usageFactor
				example.usageFactor.add((float)rs.getDouble("usage_factor"));
				example.asset_code.add(rs.getString("asset_code"));
				
				double depRate;
				double ageFactor;
				Date created = new Date();
				@SuppressWarnings("deprecation")
				int actualService = created.getYear() - acqDate.getYear();
				
				depRate = (double) (life - actualService) / life;
				System.out.println(depRate + " = " + "( " + life + " - " + actualService + ")/ " + life);
				//set the age Factor
				if(depRate > -1.0) 
					if(depRate > -0.90)
						if(depRate > -0.80)
							if(depRate > -0.70)
								if(depRate > -0.60)
									if(depRate > -0.50)
										if(depRate > -0.40)
											if(depRate > -0.30)
												if(depRate > -0.20)
													if(depRate > -0.10)
														if(depRate > -0.01)
															if(depRate != 0.0)
																if(depRate >= 0.5) ageFactor = 0.900;
																else ageFactor = depRate + 0.400;
															else ageFactor = 0.300;
														else ageFactor = 0.282;
													else ageFactor = 0.264;
												else ageFactor = 0.245;
											else ageFactor = 0.227;
										else ageFactor = 0.209;
									else ageFactor = 0.191;
								else ageFactor = 0.173;
							else ageFactor = 0.155;
						else ageFactor = 0.136;
					else ageFactor = 0.118;
				else ageFactor = 0.100;
				
				example.ageFactor.add(Float.parseFloat(Double.toString(ageFactor)));
				
			}
			model.DBEKMEANS.conn.close();
			select.close();
			rs.close();
		}
		
		catch(Exception e1){
				//err
			e1.printStackTrace();
		}
		
		int count = example.asset_code.size();
		
		//20
		model.TBLASSET.refresh();
		//21
		
		example.x.clear();
		example.y.clear();
		example.distanceC1.clear();
		example.distanceC2.clear();
		example.group.clear();
		example.oldGroup.clear();
		
		long start1 = System.currentTimeMillis();
		Random rand = new Random(); 
		int v1 = 0;
		v1 = rand.nextInt(count);
		int v2 = 0;
		
		do{
			v2 = rand.nextInt(count);
			if(count == 1) break;
		}while(v1 == v2);
		//22
		example.seed1 = new Float[2];
		example.seed1[0] = new Float(example.ageFactor.get(v1));
		example.seed1[1] = new Float(example.usageFactor.get(v1));
		example.seed2 = new Float[2];
		example.seed2[0] = new Float(example.ageFactor.get(v2));
		example.seed2[1] = new Float(example.usageFactor.get(v2));
		
		
		
		System.out.println("seed1: " +  Arrays.toString(example.seed1) + "vehicle: " +(v1+1));
		System.out.println("seed2: " + Arrays.toString(example.seed2) + "vehicle: " + (v2+1));
		//23
		example.setDistanceC1();
		example.setDistanceC2();
		
		System.out.println("distance to C1: " + Arrays.toString(example.distanceC1.toArray()));
		System.out.println("distance to C2: " + Arrays.toString(example.distanceC2.toArray()));
		//24
		view.ASSETVIEW.progressBar.setString("Clustering");
		example.setCluster();
		
		System.out.println("clustering 1: " + Arrays.toString(example.group.toArray()));
		
		example.getAverage();
		
		System.out.println("average of cluster 1: " + Arrays.toString(example.seed1));
		System.out.println("average of cluster 2: " + Arrays.toString(example.seed2));
		
		do{
			example.distanceC1.clear();
			example.distanceC2.clear();
			
			example.setDistanceC1();
			example.setDistanceC2();
			
			System.out.println("distance to C1: " + Arrays.toString(example.distanceC1.toArray()));
			System.out.println("distance to C2: " + Arrays.toString(example.distanceC2.toArray()));
			
			example.oldGroup.clear();
			for(int i=0; i<example.group.size(); i++){
				example.oldGroup.add(example.group.get(i));
			}
			example.group.clear();
			System.out.println("average of cluster 1: " + Arrays.toString(example.seed1));
			System.out.println("average of cluster 2: " + Arrays.toString(example.seed2));
			example.setCluster();
			example.getAverage();
			iteration++;
			
			if(example.oldGroup.equals(example.group)){ 
				flag = false;
				
				System.out.println("Done");
				System.out.println("cluster of iteration " + iteration + ": " + Arrays.toString(example.group.toArray()));
				System.out.println("Iteration Done: " + iteration);
			}
			else{
				flag = true;
				System.out.println("cluster of iteration " + iteration + ": " + Arrays.toString(example.group.toArray()));
				System.out.println("Another Iteration");
			}
			
		}while(flag);
		long time1 = System.currentTimeMillis() - start1;
		System.out.println(time1);
		
		k_time = time1;
		k_iteration = iteration;
		//save clustering to database
		try{
			//Insert cluster to tbl_cluster
			DBEKMEANS.TestConnection();
			String sql4 = "INSERT INTO tbl_cluster(cluster_date, run_time, iteration, isEnhanced) values(NOW(),?,?,?)";
			PreparedStatement select4 = DBEKMEANS.conn.prepareStatement(sql4);
			
			select4.setLong(1, k_time);
			select4.setInt(2, k_iteration);
			select4.setInt(3, 0);
			
			select4.executeUpdate();
		
			DBEKMEANS.conn.close();
			select4.close();
			
			DBEKMEANS.TestConnection();
			String selectMaxId = "SELECT MAX(cluster_id) as Id FROM tbl_cluster";
			PreparedStatement selectID = DBEKMEANS.conn.prepareStatement(selectMaxId);
			
			ResultSet maxID = selectID.executeQuery();
			
			if(maxID.next()) cluster_id = maxID.getInt("Id");
			maxID.close();
			selectID.close();
			DBEKMEANS.conn.close();
			
			for(int x=0; x<count; x++){
				model.F_CLUSTER cluster = new model.F_CLUSTER();
				
				cluster.setAttribute("asset_code", example.asset_code.get(x));
				cluster.setAttribute("cluster", Integer.toString(example.group.get(x)));
				cluster.setAttribute("asset_code", example.asset_code.get(x));
				cluster.setAttribute("cluster_id", Integer.toString(cluster_id));
				cluster.setAttribute("ageFactor", Float.toString(example.ageFactor.get(x)));
				cluster.setAttribute("usageFactor", Float.toString(example.usageFactor.get(x)));
				cluster.save();
				
			}
		}
		catch(Exception e2){
			e2.printStackTrace();
		}
		System.out.println("Finished Clustering");
		
		
      
      return "DONE.";
    }
    
    protected void done(){
    	load.message.setText("Finished Clustering");
    	load.progressbar.setVisible(false);
		load.button.setEnabled(true);
    }
    
    

    
 }
