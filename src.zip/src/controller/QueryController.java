package controller;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;

import model.DBEKMEANS;

public class QueryController {
	List<String> asset_code;
	int[] k_id;
	int[] e_id;
	int count;
	
	public QueryController(){
		DBEKMEANS.TestConnection();
		try{
			String asset = "SELECT count(*) as id FROM tbl_factor";
			PreparedStatement PS = DBEKMEANS.conn.prepareStatement(asset);
			
			ResultSet rs = PS.executeQuery();
			
			if(rs.next()) count = rs.getInt("id");
			
			rs.close();
			PS.close();
			DBEKMEANS.conn.close();
		}
		catch(Exception E){
			E.printStackTrace();
		}
		asset_code = new ArrayList<String>();
		e_id = new int[count];
		k_id = new int[count];
		
		for(int x=0; x<count; x++){
			e_id[x] = 0;
			k_id[x] = 0;
		}
		
		view.ASSETVIEW.levelModel.setRowCount(0);
		view.ASSETVIEW.netModel.setRowCount(0);
		view.ASSETVIEW.salvageModel.setRowCount(0);
	}
	
	public void level(){
		
		DBEKMEANS.TestConnection();
		String nameCT = view.ASSETVIEW.Filter.getSelectedItem().toString();
		String nameST = view.ASSETVIEW.sbFilter.getSelectedItem().toString();
		String levelSelect = "";
		
		try{
			if (nameCT.equals("") &&  nameST.equals(""))
				levelSelect = "SELECT CT.category_name, S.subcategory_name, F.asset_code, A.fixedAssetName, F.age_factor, F.usage_factor, C.isEnhanced, CD.cluster, C.cluster_id" + 
					" FROM tbl_factor F left Join tbl_cluster_detail CD on F.factor_id = CD.factor_id" +
					" join tbl_asset A on A.asset_code = F.asset_code"
					+ " join tbl_subcategory S on A.asset_category = S.subcategory_id"
					+ " join tbl_category CT on S.category_id = CT.category_id" +
					" left join tbl_cluster C on CD.cluster_id = C.cluster_id"
					+ " WHERE A.disposed IS NULL"
					+ " Order by S.subcategory_name, F.asset_code";
			else if(!nameCT.equals("") &&  nameST.equals("")) levelSelect = "SELECT CT.category_name, S.subcategory_name, F.asset_code, A.fixedAssetName, F.age_factor, F.usage_factor, C.isEnhanced, CD.cluster, C.cluster_id" + 
					" FROM tbl_factor F left Join tbl_cluster_detail CD on F.factor_id = CD.factor_id" +
					" join tbl_asset A on A.asset_code = F.asset_code"
					+ " join tbl_subcategory S on A.asset_category = S.subcategory_id"
					+ " join tbl_category CT on S.category_id = CT.category_id" +
					" left join tbl_cluster C on CD.cluster_id = C.cluster_id"
					+ " WHERE A.disposed IS NULL AND CT.category_name = '" + nameCT 
					+ "' Order by S.subcategory_name, F.asset_code";
			else levelSelect = "SELECT CT.category_name, S.subcategory_name, F.asset_code, A.fixedAssetName, F.age_factor, F.usage_factor, C.isEnhanced, CD.cluster, C.cluster_id" + 
					" FROM tbl_factor F left Join tbl_cluster_detail CD on F.factor_id = CD.factor_id" +
					" join tbl_asset A on A.asset_code = F.asset_code"
					+ " join tbl_subcategory S on A.asset_category = S.subcategory_id"
					+ " join tbl_category CT on S.category_id = CT.category_id" +
					" left join tbl_cluster C on CD.cluster_id = C.cluster_id"
					+ " WHERE A.disposed IS NULL AND S.subcategory_name = '" + nameST + "' AND CT.category_name = '" + nameCT 
					+ "' Order by S.subcategory_name, F.asset_code";
			PreparedStatement levelPS = DBEKMEANS.conn.prepareStatement(levelSelect);
			ResultSet levelRS = levelPS.executeQuery();
			asset_code.clear();
			
			while(levelRS.next()){
				String id = levelRS.getString("asset_code");
				String name = levelRS.getString("fixedAssetName");
				String category = levelRS.getString("category_name");
				String sub = levelRS.getString("subcategory_name");
				int cluster_id = levelRS.getInt("cluster_id");
				int level = levelRS.getInt("cluster");
				int isEnhanced = levelRS.getInt("isEnhanced");
				double age = levelRS.getDouble("age_Factor");
				double usage = levelRS.getDouble("usage_factor");
				
				String mString = "";
				if(level == 2) mString = "MINOR";
				else if(level == 1) mString = "MAJOR";
				else mString = "null";
				
				if(asset_code.contains(id)){
					int index = asset_code.indexOf(id);
					int idK = k_id[index];
					int idE = e_id[index];
					
					 
					if(isEnhanced == 1){
						
						if(idE < cluster_id){
							view.ASSETVIEW.levelModel.setValueAt(mString, index, 7);
							e_id[index] = cluster_id;
						}
							
						
						
					}
					else {
						if(idK < cluster_id){
							view.ASSETVIEW.levelModel.setValueAt(mString, index, 6);
							k_id[index] = cluster_id;
						}
					}
				}
				
				else{
					if(isEnhanced == 1){
						Object[] row = {id, name, category, sub, usage, age, "null", mString};
						
						view.ASSETVIEW.levelModel.addRow(row);
						
						asset_code.add(id);
						e_id[asset_code.indexOf(id)] = cluster_id;
						
					}
					
					else{
						Object[] row = {id, name, category, sub, usage, age, mString, "null"};
						
						view.ASSETVIEW.levelModel.addRow(row);
						
						asset_code.add(id);
						k_id[asset_code.indexOf(id)] = cluster_id;
					}
				}
				
				
				
			}
			
			levelRS.close();
			levelPS.close();
			DBEKMEANS.conn.close();
			
		}
		catch(Exception E){
			E.printStackTrace();
		}
	}
	
	public void net(){
		DBEKMEANS.TestConnection();
		try{
			String netStatement = "SELECT A.asset_code, A.fixedAssetName, CT.category_name, S.subcategory_name, A.acq_date, A.acq_value, A.salvage_value, acq_value - ((acq_value - salvage_value)/(service_life * 12) * (DATEDIFF(NOW(), acq_date) * 0.0328767)) as net, (acq_value - salvage_value)/(service_life * 12) as dep "
					+ " from tbl_asset A"
					+ " join tbl_subcategory S on S.subcategory_id = A.asset_category"
					+ " join tbl_category CT on CT.category_id = S.category_id"
					+ " Where A.disposed IS NULL"
					+ " ORDER BY S.subcategory_name, A.asset_code";
			PreparedStatement netPS = DBEKMEANS.conn.prepareStatement(netStatement);
			
			ResultSet netRS = netPS.executeQuery();
			
			while(netRS.next()){
				DecimalFormat df = new DecimalFormat("#.00");
				
				String code = netRS.getString("asset_code");
				String name = netRS.getString("fixedAssetName");
				Date acq_date = netRS.getDate("acq_date");
				String acq_value = "Php " + df.format(netRS.getDouble("acq_value"));
				String category = netRS.getString("category_name");
				String sub = netRS.getString("subcategory_name");
				String dep = "Php " + df.format(netRS.getDouble("dep"));
				String salvage_value = "Php " + df.format(netRS.getDouble("salvage_value")); 
				String net_value = "Php " + df.format(netRS.getDouble("net")); 
				
				Object[] row = {code, name, category, sub, acq_date, acq_value, salvage_value, dep, net_value};
				
				view.ASSETVIEW.netModel.addRow(row);
				
			}
			
			netRS.close();
			netPS.close();
			DBEKMEANS.conn.close();
			
		}
		catch(Exception E){
			E.printStackTrace();
		}
	}
	
	public void salvage(){
		DBEKMEANS.TestConnection();
		try{
			String salStatement = "SELECT asset_code, fixedAssetName, CT.category_name, S.subcategory_name, acq_date, acq_value, salvage_value, acq_value - ((acq_value - salvage_value)/(service_life * 12) * (DATEDIFF(NOW(), acq_date) * 0.0328767)) as net, (acq_value - salvage_value)/(service_life * 12) AS dep from tbl_asset A"
					+ " join tbl_subcategory S on S.subcategory_id = A.asset_category"
					+ " join tbl_category CT on S.category_id = CT.category_id"
									+ " WHERE disposed is null AND acq_value - ((acq_value - salvage_value)/(service_life * 12) * (DATEDIFF(NOW(), acq_date) * 0.0328767)) <= salvage_value"
									+ " ORDER BY S.subcategory_name";
			PreparedStatement salPS = DBEKMEANS.conn.prepareStatement(salStatement);
			
			ResultSet salRS = salPS.executeQuery();
			
			while(salRS.next()){
				DecimalFormat df = new DecimalFormat("#.00");
				
				String code = salRS.getString("asset_code");
				String name = salRS.getString("fixedAssetName");
				Date acq_date = salRS.getDate("acq_date");
				String category = salRS.getString("category_name");
				String sub = salRS.getString("subcategory_name");
				String acq_value = "Php " + df.format(salRS.getDouble("acq_value"));
				String salvage_value = "Php " + df.format(salRS.getDouble("salvage_value")); 
				String net_value = "Php " + df.format(salRS.getDouble("net")); 
				String dep = "Php " + df.format(salRS.getDouble("dep")); 
				
				Object[] row = {code, name, category, sub, acq_date, acq_value, salvage_value, dep, net_value,};
				
				view.ASSETVIEW.salvageModel.addRow(row);
				
			}
			
			salRS.close();
			salPS.close();
			DBEKMEANS.conn.close();
			
		}
		catch(Exception E){
			E.printStackTrace();
		}
	}
	
	public void indivKmeans(String asset_code){
		String name = "";
		int clusterBatch = 0;
		int cluster = 0;
		int iteration = 0;
		String sCluster = "";
		DBEKMEANS.TestConnection();
		try{
			String kmeans = "SELECT A.asset_code, A.fixedAssetName, CD.cluster_id, CD.cluster, C.isEnhanced, C.iteration"
					+ " FROM tbl_asset A"
					+ " join tbl_factor F on A.asset_code = F.asset_code"
					+ " left join tbl_cluster_detail CD on F.factor_id = CD.factor_id"
					+ " join tbl_cluster C on CD.cluster_id = C.cluster_id"
					+ " WHERE A.asset_code = ?"
					+ " and C.isEnhanced = 0"
					+ " and C.cluster_id = "
					+ " (SELECT max(CD.cluster_id)"
					+ " FROM tbl_asset A"
					+ " join tbl_factor F on A.asset_code = F.asset_code"
					+ " left join tbl_cluster_detail CD on F.factor_id = CD.factor_id"
					+ " join tbl_cluster C on CD.cluster_id = C.cluster_id"
					+ " WHERE A.asset_code = ?"
					+ " and C.isEnhanced = 0)";
			PreparedStatement query = DBEKMEANS.conn.prepareStatement(kmeans);
			query.setString(1, asset_code);
			query.setString(2, asset_code);
			ResultSet rs = query.executeQuery();
			
			if(rs.next()){
				name = rs.getString("fixedAssetName");
				clusterBatch = rs.getInt("cluster_id");
				cluster = rs.getInt("cluster");
				iteration = rs.getInt("iteration");
				if(cluster == 1) sCluster = "MAJOR";
				else if( cluster == 2) sCluster = "MINOR";
				else sCluster = "UNCLUSTERED";
				
			
				view.ASSETVIEW.kMeanAsset.setText(asset_code + " : " + name);
				view.ASSETVIEW.kMeanLevel.setText("Level of Maintenance: " + sCluster);
				view.ASSETVIEW.kMeanIteration.setText("Number of Iterations: " + iteration);
				view.ASSETVIEW.kMeanBatch.setText("Clustering Batch: " + clusterBatch);
				
			}
			else JOptionPane.showMessageDialog(null, "ASSET STILL UNCLUSTERED USING KMEANS");
			
			rs.close();
			DBEKMEANS.conn.close();
			
		}
		catch(Exception E){
			E.printStackTrace();
		}
	}
	
	public void indivEKmeans(String asset_code){
		String name = "";
		int clusterBatch = 0;
		int cluster = 0;
		int iteration = 0;
		String sCluster = "";
		DBEKMEANS.TestConnection();
		try{
			String kmeans = "SELECT A.asset_code, A.fixedAssetName, CD.cluster_id, CD.cluster, C.isEnhanced, C.iteration"
					+ " FROM tbl_asset A"
					+ " join tbl_factor F on A.asset_code = F.asset_code"
					+ " left join tbl_cluster_detail CD on F.factor_id = CD.factor_id"
					+ " join tbl_cluster C on CD.cluster_id = C.cluster_id"
					+ " WHERE A.asset_code = ?"
					+ " and C.isEnhanced = 1"
					+ " and C.cluster_id = "
					+ " (SELECT max(CD.cluster_id)"
					+ " FROM tbl_asset A"
					+ " join tbl_factor F on A.asset_code = F.asset_code"
					+ " left join tbl_cluster_detail CD on F.factor_id = CD.factor_id"
					+ " join tbl_cluster C on CD.cluster_id = C.cluster_id"
					+ " WHERE A.asset_code = ?"
					+ " and C.isEnhanced = 1)";
			PreparedStatement query = DBEKMEANS.conn.prepareStatement(kmeans);
			query.setString(1, asset_code);
			query.setString(2, asset_code);
			ResultSet rs = query.executeQuery();
			
			if(rs.next()){
				name = rs.getString("fixedAssetName");
				clusterBatch = rs.getInt("cluster_id");
				cluster = rs.getInt("cluster");
				iteration = rs.getInt("iteration");
				if(cluster == 1) sCluster = "MAJOR";
				else if( cluster == 2) sCluster = "MINOR";
				else sCluster = "UNCLUSTERED";
				
			
				view.ASSETVIEW.eKMeanAsset.setText(asset_code + " : " + name);
				view.ASSETVIEW.eKMeanLevel.setText("Level of Maintenance: " + sCluster);
				view.ASSETVIEW.eKMeanIteration.setText("Number of Iterations: " + iteration);
				view.ASSETVIEW.eKMeanBatch.setText("Clustering Batch: " + clusterBatch);
			}
			
			else JOptionPane.showMessageDialog(null, "ASSET STILL UNCLUSTERED USING ENHANCED");
			rs.close();
			DBEKMEANS.conn.close();
			
		}
		catch(Exception E){
			E.printStackTrace();
		}
	}
}
