package controller;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Date;

import javax.swing.SwingWorker;

import eKMEANS.EKMEANS;
import model.DBEKMEANS;

public class EnhancedCluster extends SwingWorker<String, Object>{
	
	long e_time;
	long k_time;
	int e_iteration;
	int k_iteration;
	int cluster_id = 0;
	int scId = 0;
	int count = 0;
	
	//prepare indeterminate loading
	view.Loading load;
	
    protected String doInBackground() {
    	// Do my downloading code
    	
    	//prepare indeterminate loading
    	load = new view.Loading();
    	load.progressbar.setIndeterminate(true);
    	
    	//Select sub category ID needed for clustering
    	String category = view.ASSETVIEW.k_subCategoryField.getSelectedItem().toString();
    	String selectCategoryID = "SELECT CT.category_id FROM tbl_asset A join tbl_subcategory S on A.asset_category = S.subcategory_id"
    			+ " join tbl_category CT on S.category_id = CT.category_id"
    			+ " WHERE category_name = ?";
    	
    	DBEKMEANS.TestConnection();
    	PreparedStatement psCID;
    	
		try {
			psCID = DBEKMEANS.conn.prepareStatement(selectCategoryID);
			psCID.setString(1, category);
	    	ResultSet rsCID = psCID.executeQuery();
	    	int subID = 0;
	    	if(rsCID.next()){
	    		subID = rsCID.getInt("category_id");
	    		
	    	}
	    	scId = subID;
	    	rsCID.close();
	    	psCID.close();
	    	DBEKMEANS.conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	// end of selecting sub category 
      
		int progress = 0;
		DBEKMEANS.TestConnection();
		//EKMEANS 
		EKMEANS example = new EKMEANS();
		boolean flag = false;
		int iteration = 1;
		
		example.initialize();
		// 1 get Inputs
		
		try{
			String sql = "SELECT tbl_asset.asset_code, usage_factor, age_factor, acq_date, service_life FROM tbl_asset join tbl_factor on tbl_asset.asset_code = tbl_factor.asset_code "
					+ " join tbl_subcategory S on S.subcategory_id = tbl_asset.asset_category"
					+ " join tbl_category CT on CT.category_id = S.category_id "
					+ " WHERE disposed IS NULL AND CT.category_id = ? order by tbl_asset.asset_code";
			PreparedStatement select = DBEKMEANS.conn.prepareStatement(sql);
			
			select.setInt(1, scId);
			
			ResultSet rs = select.executeQuery();
			while(rs.next()){
				
				Date acqDate = rs.getDate("acq_date");
				int life = rs.getInt("service_life");
				//gets usageFactor
				example.usageFactor.add((float)rs.getDouble("usage_factor"));
				example.asset_code.add(rs.getString("asset_code"));
				
				double depRate;
				double ageFactor;
				Date created = new Date();
				@SuppressWarnings("deprecation")
				int actualService = created.getYear() - acqDate.getYear();
				
				depRate = (double) (life - actualService) / life;
				System.out.println(depRate + " = " + "( " + life + " - " + actualService + ")/ " + life);
				//set the age Factor
				if(depRate > -1.0) 
					if(depRate > -0.90)
						if(depRate > -0.80)
							if(depRate > -0.70)
								if(depRate > -0.60)
									if(depRate > -0.50)
										if(depRate > -0.40)
											if(depRate > -0.30)
												if(depRate > -0.20)
													if(depRate > -0.10)
														if(depRate > -0.01)
															if(depRate != 0.0)
																if(depRate >= 0.5) ageFactor = 0.900;
																else ageFactor = depRate + 0.400;
															else ageFactor = 0.300;
														else ageFactor = 0.282;
													else ageFactor = 0.264;
												else ageFactor = 0.245;
											else ageFactor = 0.227;
										else ageFactor = 0.209;
									else ageFactor = 0.191;
								else ageFactor = 0.173;
							else ageFactor = 0.155;
						else ageFactor = 0.136;
					else ageFactor = 0.118;
				else ageFactor = 0.100;
				
				example.ageFactor.add(Float.parseFloat(Double.toString(ageFactor)));
				
			}
			progress = progress + 4;
			view.ASSETVIEW.progressBar.setValue(progress);
			view.ASSETVIEW.progressBar.setString("Getting Inputs");
			model.DBEKMEANS.conn.close();
			select.close();
			rs.close();
		}
		
		catch(Exception e1){
				//err
			e1.printStackTrace();
		}
		
		
		//6 get sum of usage
		//example.sumY = example.getSum(example.usageFactor);
		
		//7 get mean of usage
		//example.setYRF();
		
		//8 get lowest point of age
		
		System.out.println();
		
		//System.out.println("age factor: " + Arrays.toString(example.ageFactor.toArray()));
		//System.out.println("usage factor: " + Arrays.toString(example.usageFactor.toArray()));
		
		//System.out.println();
		
		//System.out.println("mean of age factor: " + Arrays.toString(example.x.toArray()));
		//System.out.println("mean of usage factor: " + Arrays.toString(example.y.toArray()));
		long start = System.currentTimeMillis();
		
		//10 get seed 1
		example.getSeed1();
		
		//11 get seed 2
		example.getSeed2();
		
		System.out.println("seed1: " +  Arrays.toString(example.seed1) + "vehicle: " + example.point1);
		System.out.println("seed2: " + Arrays.toString(example.seed2) + "vehicle: " + example.point2);
		
		//12 get Distance 1
		example.setDistanceC1();
		//13 get Distance 2
		example.setDistanceC2();
		
		System.out.println("distance to C1: " + Arrays.toString(example.distanceC1.toArray()));
		System.out.println("distance to C2: " + Arrays.toString(example.distanceC2.toArray()));
		
		//14 get Clustering
		example.setCluster();
		
		
		System.out.println("clustering 1: " + Arrays.toString(example.group.toArray()));
	
		example.getAverage();
		
		System.out.println("average of cluster 1: " + Arrays.toString(example.seed1));
		System.out.println("average of cluster 2: " + Arrays.toString(example.seed2));
		
		do{
			example.distanceC1.clear();
			example.distanceC2.clear();
			
			example.setDistanceC1();
			example.setDistanceC2();
			
			
			example.oldGroup.clear();
			for(int i=0; i<example.group.size(); i++){
				example.oldGroup.add(example.group.get(i));
			}
			example.group.clear();
			example.setCluster();
			example.getAverage();
			iteration++;
			
			if(example.oldGroup.equals(example.group)){ 
				flag = false;
				
				System.out.println("Done");
				System.out.println("cluster of iteration " + iteration + ": " + Arrays.toString(example.group.toArray()));
				System.out.println("Iteration Done: " + iteration);
			}
			else{
				flag = true;
				System.out.println("cluster of iteration " + iteration + ": " + Arrays.toString(example.group.toArray()));
				System.out.println("Another Iteration");
			}
			
		}while(flag); 
		long time = System.currentTimeMillis() - start;
		System.out.println(time);
		
		e_time = time;
		e_iteration = iteration;
		count = example.asset_code.size();
		try{
			//17
			
			model.DBEKMEANS.TestConnection();
			String sql1 = "INSERT INTO tbl_cluster(run_time, iteration, cluster_date, isEnhanced) VALUES(?, ?, NOW(), 1)";
			PreparedStatement select1 = DBEKMEANS.conn.prepareStatement(sql1);
			
			select1.setLong(1, e_time);
			select1.setInt(2, e_iteration);
			
			select1.executeUpdate();
			
			//18
			select1.close();
			DBEKMEANS.conn.close();
			
			
			model.DBEKMEANS.TestConnection();
			
			String sql2 = "SELECT MAX(cluster_id) AS ID FROM tbl_cluster";
			PreparedStatement select2 = DBEKMEANS.conn.prepareStatement(sql2);
			
			ResultSet rs2 = select2.executeQuery();
			
			//18
			rs2.next();
			cluster_id = rs2.getInt("ID");
			System.out.println(cluster_id);
			DBEKMEANS.conn.close();
			select2.close();
			rs2.close();
			
			
			//19
			for(int x=0; x<count; x++){
				model.F_CLUSTER cluster = new model.F_CLUSTER();
				
				
				cluster.setAttribute("asset_code", example.asset_code.get(x));
				cluster.setAttribute("cluster_id", Integer.toString(cluster_id));
				cluster.setAttribute("ageFactor", Float.toString(example.ageFactor.get(x)));
				cluster.setAttribute("usageFactor", Float.toString(example.usageFactor.get(x)));
				cluster.setAttribute("cluster", Integer.toString(example.group.get(x)));
				
				cluster.save();
			}
			
		}
		catch(Exception e2){
			e2.printStackTrace();
		}
		
		
      
      return "DONE";
    }

    protected void done(){
    	load.message.setText("Finished Clustering");
    	load.progressbar.setVisible(false);
		load.button.setEnabled(true);
    }
    
    
 }
