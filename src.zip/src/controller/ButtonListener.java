package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import javax.swing.JOptionPane;

import model.DBEKMEANS;

public class ButtonListener implements ActionListener{
	model.R_CATEGORY categoryUP = new model.R_CATEGORY();
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == view.ASSETVIEW.addButton){
			//when addButton is pressed
			String propertyNo = view.ASSETVIEW.assetCodeField.getText();
			if(propertyNo.equals("") && view.ASSETVIEW.assetNameField.getText().equals("")){
					JOptionPane.showMessageDialog(null, "No Asset Added");
					return;
			}
			
			model.TBLASSET asset = new model.TBLASSET();
			try {
			asset.setAttribute("asset_code", view.ASSETVIEW.assetCodeField.getText());
			asset.setAttribute("asset_name", view.ASSETVIEW.assetNameField.getText());
			asset.setAttribute("category_name", view.ASSETVIEW.f_categoryField.getSelectedItem().toString());
			asset.setAttribute("subcategory_name", view.ASSETVIEW.f_subCategory.getSelectedItem().toString());
			
			String datePattern = "yyyy-MM-dd";
		    SimpleDateFormat dateFormatter = new SimpleDateFormat(datePattern);
		    
			asset.setAttribute("acqDate", dateFormatter.format(view.ASSETVIEW.datePicker.getModel().getValue()));
			asset.setAttribute("life", view.ASSETVIEW.lifeSpinner.getModel().getValue().toString());
			asset.setAttribute("acq_value", view.ASSETVIEW.acqValueField.getText());
			asset.setAttribute("salvage_value", view.ASSETVIEW.salvageValueField.getText());
			
			
			asset.save();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			
		}
		
		else if(e.getSource() == view.ASSETVIEW.clearButton){
			view.ASSETVIEW.assetCodeField.setText(null);
			view.ASSETVIEW.assetNameField.setText(null);
			view.ASSETVIEW.datePicker.getModel().setValue(null);
			view.ASSETVIEW.lifeSpinner.getModel().setValue(0);
			view.ASSETVIEW.acqValueField.setText("0.0");
			view.ASSETVIEW.salvageValueField.setText("0.0");
		}
		
		else if(e.getSource() == view.ASSETVIEW.searchButton){
			String number = JOptionPane.showInputDialog("Input Property Number:");
			
			model.TBLASSET search = new model.TBLASSET();
			boolean asset = search.find(number);
			if(asset){
				view.ASSETVIEW.assetCodeField.setText(search.asset_code);
				view.ASSETVIEW.assetNameField.setText(search.assetName);
				DateFormat format = new SimpleDateFormat("yyyy-mm-dd", Locale.ENGLISH);
				Date date = new Date();
				try {
					date = format.parse(search.acqDate);
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				view.ASSETVIEW.modelDate.setValue(date);;
				view.ASSETVIEW.lifeSpinner.getModel().setValue(search.life);
				view.ASSETVIEW.acqValueField.setText(Double.toString(search.acq_value));
				view.ASSETVIEW.salvageValueField.setText(Double.toString(search.salvage_value));
				
			}
			else JOptionPane.showMessageDialog(null, "Cannot Find Fixed Asset with Property Number: " + number);
			
			
		}
		
		else if(e.getSource() == view.ASSETVIEW.deleteButton){
			int row = view.ASSETVIEW.dataTable.getSelectedRow();
			model.TBLASSET asset = new model.TBLASSET();
			if(row != -1){
				
					asset.dispose(view.ASSETVIEW.dataTable.getValueAt(row, 0).toString());
				
			}
			else{
				if(view.ASSETVIEW.assetCodeField.getText().equals(""))
					JOptionPane.showMessageDialog(null, "No fixed asset is selected in table nor property searched");
				else{
					
						asset.dispose(view.ASSETVIEW.assetCodeField.getText());
					
				}
			}
		}
		
		else if(e.getSource() == view.ASSETVIEW.editButton){
			String propertyNo = view.ASSETVIEW.assetCodeField.getText();
			if(propertyNo.equals("")){
				if(view.ASSETVIEW.dataTable.getSelectedRow() == -1)
					JOptionPane.showMessageDialog(null, "Select or Search for a Product First!");
				return;
			}
			view.ASSETVIEW.editButton.setEnabled(false);
			view.ASSETVIEW.updateButton.setEnabled(true);
			view.ASSETVIEW.assetCodeField.setEditable(false);
			
		}
		
		else if(e.getSource() == view.ASSETVIEW.updateButton){
			model.TBLASSET asset = new model.TBLASSET();
			try {
			asset.setAttribute("asset_code", view.ASSETVIEW.assetCodeField.getText());
			asset.setAttribute("asset_name", view.ASSETVIEW.assetNameField.getText());
			asset.setAttribute("category_name", view.ASSETVIEW.f_categoryField.getSelectedItem().toString());
			asset.setAttribute("subcategory_name", view.ASSETVIEW.f_subCategory.getSelectedItem().toString());
			
			String datePattern = "yyyy-MM-dd";
		    SimpleDateFormat dateFormatter = new SimpleDateFormat(datePattern);
		    
			asset.setAttribute("acqDate", dateFormatter.format(view.ASSETVIEW.datePicker.getModel().getValue()));
			asset.setAttribute("life", view.ASSETVIEW.lifeSpinner.getModel().getValue().toString());
			asset.setAttribute("acq_value", view.ASSETVIEW.acqValueField.getText());
			asset.setAttribute("salvage_value", view.ASSETVIEW.salvageValueField.getText());
			
			
			asset.update();
			view.ASSETVIEW.editButton.setEnabled(true);
			view.ASSETVIEW.updateButton.setEnabled(false);
			view.ASSETVIEW.assetCodeField.setEditable(true);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
		// CLUSTERING
		else if(e.getSource() == view.ASSETVIEW.clusterButton){
			
			String category = view.ASSETVIEW.k_subCategoryField.getSelectedItem().toString();
			String algorithm = view.ASSETVIEW.algorithm.getSelectedItem().toString();
		
			if(category.equals("")){
				JOptionPane.showMessageDialog(null, "No Category Selected");
			}
			else{
				
				if(algorithm.equals("")){
					JOptionPane.showMessageDialog(null, "No Algorithm Selected");
				}
				else{
					if(algorithm.equals("K-MEANS")) new Cluster().execute();
					else new EnhancedCluster().execute();
				}
			}
			
		}
		
		//UTILITY CATEGORY
		else if(e.getSource() == view.ASSETVIEW.c_Save){
			model.R_CATEGORY category = new model.R_CATEGORY();
			
			category.setAttribute("category_name", view.ASSETVIEW.categoryField.getText().toUpperCase());
			category.setAttribute("subcategory_name", view.ASSETVIEW.subCategory.getText().toUpperCase());
			
			boolean saved = category.save();
			
			if(!saved) return;
			
			Object[] row ={category.category_name};
			
			
			view.ASSETVIEW.categoryModel.addRow(row);
			
			view.ASSETVIEW.categoryTB.getSelectionModel().addListSelectionListener(view.ASSETVIEW.table);
			
		}
		
		else if(e.getSource() == view.ASSETVIEW.c_Edit){
			if(view.ASSETVIEW.categoryField.getText().equals("")){
				JOptionPane.showMessageDialog(null, "Category Field not selected");
				return;
			}
			if(view.ASSETVIEW.subCategory.getText().equals("")){
				JOptionPane.showMessageDialog(null, "Sub Category is Empty");
				return;
			}
			
			boolean look = categoryUP.find(view.ASSETVIEW.categoryField.getText());
			if(look) JOptionPane.showMessageDialog(null, "Successfully Found");
			else return;
			
			view.ASSETVIEW.c_Update.setEnabled(true);
			view.ASSETVIEW.c_Edit.setEnabled(false);
			
		}
		
		else if(e.getSource() == view.ASSETVIEW.c_Update){
			categoryUP.update(categoryUP.category_name, categoryUP.category_id);
			
			model.R_CATEGORY category = new model.R_CATEGORY();
			category.refresh();
			
			view.ASSETVIEW.c_Update.setEnabled(false);
			view.ASSETVIEW.c_Edit.setEnabled(true);
		}
		
		else if(e.getSource() == view.ASSETVIEW.c_Delete){
			if(view.ASSETVIEW.categoryField.getText().equals("")){
				JOptionPane.showMessageDialog(null, "Category Field not selected");
				return;
			}
			if(view.ASSETVIEW.subCategory.getText().equals("")){
				JOptionPane.showMessageDialog(null, "Sub Category is Empty");
				return;
			}
			
			model.R_CATEGORY category = new model.R_CATEGORY();
			
			boolean look = category.find(view.ASSETVIEW.categoryField.getText());
			if(look) JOptionPane.showMessageDialog(null, "Successfully Found");
			else return;
			
			category.delete();
			
		}
		
		
		else if(e.getSource() == view.ASSETVIEW.s_Save){
			model.R_SUBCATEGORY subcategory = new model.R_SUBCATEGORY();
			
			subcategory.setAttribute("category_name", view.ASSETVIEW.CB_category.getSelectedItem().toString());
			subcategory.setAttribute("subcategory_name", view.ASSETVIEW.subCategory.getText());
			
			subcategory.save();
			
			Object[] row ={subcategory.category_name, subcategory.subcategory_name};
			
			
			
			
			view.ASSETVIEW.subcategoryModel.addRow(row);
			
			view.ASSETVIEW.subcategoryTB.getSelectionModel().addListSelectionListener(view.ASSETVIEW.table);
			
		}
		
		else if(e.getSource() == view.ASSETVIEW.fb_Save){
			//Save Factors
			String asset_code = view.ASSETVIEW.f_assetCodeField.getSelectedItem().toString();
			String age_factor = view.ASSETVIEW.ff_ageFactor.getText();
			String usage_factor = view.ASSETVIEW.ff_usageFactor.getText();
			
			DBEKMEANS.TestConnection();
			
			try{
				String select = "SELECT factor_id FROM tbl_factor WHERE asset_code = ?";
				PreparedStatement query = DBEKMEANS.conn.prepareStatement(select);
				
				query.setString(1, asset_code);
				ResultSet result = query.executeQuery();
				
				if(result.next()){
					String update = "UPDATE tbl_factor set usage_factor= ?, age_factor = ?, factor_date = NOW() WHERE factor_id = ?";
					int factor_id = result.getInt("factor_id");
					PreparedStatement updateSTMT =  DBEKMEANS.conn.prepareStatement(update);
					
					updateSTMT.setDouble(1, Double.parseDouble(usage_factor));
					updateSTMT.setDouble(2, Double.parseDouble(age_factor));
					updateSTMT.setInt(3, factor_id);
					
					updateSTMT.executeUpdate();
					
					JOptionPane.showMessageDialog(null, "Successfully Updated");
				}
				
				else {
					String insert = "INSERT INTO tbl_factor(asset_code, usage_factor, age_factor, factor_date) VALUES (?,?,?, NOW())";
					PreparedStatement insertSTMT = DBEKMEANS.conn.prepareStatement(insert);
					
					insertSTMT.setString(1, asset_code);
					insertSTMT.setDouble(2, Double.parseDouble(usage_factor));
					insertSTMT.setDouble(3, Double.parseDouble(age_factor));
					
					insertSTMT.executeUpdate();
					
					JOptionPane.showMessageDialog(null, "Successfully Saved");
				}
				
				model.TBLASSET.refresh();
			}
			catch(Exception exc){
				exc.printStackTrace();
			}
			//Save Factors
		}
		
		else if(e.getSource() == view.ASSETVIEW.filterButton){
			controller.QueryController query = new controller.QueryController();
			query.net();
			query.level();
			query.salvage();
		}
		
		else if(e.getSource() == view.ASSETVIEW.indivButton){
			controller.QueryController query = new controller.QueryController();
			String asset = view.ASSETVIEW.listAsset.getSelectedItem().toString();
			if(!asset.equals("")){
				query.indivKmeans(asset);
				query.indivEKmeans(asset);
				query.net();
				query.level();
				query.salvage();
			}
			else JOptionPane.showMessageDialog(null, "No Selected Asset");
		}
		
		else if(e.getSource() == view.ASSETVIEW.dashFilterButton){
			view.ASSETVIEW.dashBoardCenter.remove(chartController.chartPanel);
			@SuppressWarnings("unused")
			chartController chart = new chartController();
			view.ASSETVIEW.dashBoardCenter.repaint();
			view.ASSETVIEW.dashBoardCenter.validate();
			
			controller.dashboardController dashboard = new controller.dashboardController();
			dashboard.kConsistency();
			dashboard.eConsistency();
			dashboard.avgStat();
		}
        
		
		
		
	}

}
