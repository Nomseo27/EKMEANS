package controller;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import model.DBEKMEANS;
import view.ASSETVIEW;

public class DropDownListener implements ItemListener {

	@Override
	public void itemStateChanged(ItemEvent arg0) {
		// TODO Auto-generated method stub
		if(arg0.getSource() == view.ASSETVIEW.f_categoryField){
			DBEKMEANS.LoadDriver();
			DBEKMEANS.TestConnection();
			try {
				String subCategoryList = "SELECT subcategory_name FROM tbl_subcategory S join tbl_category C on S.category_id = C.category_id  where category_name = ?";
		
				PreparedStatement select =  DBEKMEANS.conn.prepareStatement(subCategoryList);
			
				select.setString(1, ASSETVIEW.f_categoryField.getSelectedItem().toString());
				ResultSet rs = select.executeQuery();
				ASSETVIEW.f_subCategory.removeAllItems();
				ASSETVIEW.f_subCategory.addItem("");
			
				while(rs.next()){
					ASSETVIEW.f_subCategory.addItem(rs.getString("subcategory_name"));
				}
			
				rs.close();
				select.close();
				DBEKMEANS.conn.close();
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		else if(arg0.getSource() == view.ASSETVIEW.f_assetCodeField){
			DBEKMEANS.LoadDriver();
			DBEKMEANS.TestConnection();
			try {
				String asset_detail = "Select A.*, category_name, subcategory_name from tbl_asset A join tbl_subcategory S on A.asset_category = S.subcategory_id join tbl_category C on S.category_id = C.category_id where asset_code = ?";
		
				PreparedStatement select =  DBEKMEANS.conn.prepareStatement(asset_detail);
			
				select.setString(1, ASSETVIEW.f_assetCodeField.getSelectedItem().toString());
				ResultSet rs = select.executeQuery();
				
				while(rs.next()){
					view.ASSETVIEW.f_assetNameField.setText(rs.getString("fixedAssetName"));
					view.ASSETVIEW.ff_category.setText(rs.getString("category_name"));
					view.ASSETVIEW.ff_subcategory.setText(rs.getString("subcategory_name"));
					view.ASSETVIEW.f_date.setText(rs.getDate("acq_date").toString());
					view.ASSETVIEW.f_acqValueField.setText(Double.toString(rs.getDouble("acq_value")));
					view.ASSETVIEW.f_lifeSpinner.getModel().setValue(rs.getInt("service_life"));
					view.ASSETVIEW.f_salvageValueField.setText(Double.toString(rs.getDouble("salvage_value")));
					
					DateFormat format = new SimpleDateFormat("Y-M-d", Locale.ENGLISH);
					
					Date acqDate = format.parse(view.ASSETVIEW.f_date.getText());
					int life = Integer.parseInt(view.ASSETVIEW.f_lifeSpinner.getModel().getValue().toString());
					double depRate;
					double ageFactor;
					Date created = new Date();
					@SuppressWarnings("deprecation")
					int actualService = created.getYear() - acqDate.getYear();
					
					depRate = (double) (life - actualService) / life;
					System.out.println(depRate + " = " + "( " + life + " - " + actualService + ")/ " + life);
					//set the age Factor
					if(depRate > -1.0) 
						if(depRate > -0.90)
							if(depRate > -0.80)
								if(depRate > -0.70)
									if(depRate > -0.60)
										if(depRate > -0.50)
											if(depRate > -0.40)
												if(depRate > -0.30)
													if(depRate > -0.20)
														if(depRate > -0.10)
															if(depRate > -0.01)
																if(depRate != 0.0)
																	if(depRate >= 0.5) ageFactor = 0.900;
																	else ageFactor = depRate + 0.400;
																else ageFactor = 0.300;
															else ageFactor = 0.282;
														else ageFactor = 0.264;
													else ageFactor = 0.245;
												else ageFactor = 0.227;
											else ageFactor = 0.209;
										else ageFactor = 0.191;
									else ageFactor = 0.173;
								else ageFactor = 0.155;
							else ageFactor = 0.136;
						else ageFactor = 0.118;
					else ageFactor = 0.100;
					
					
					System.out.println(ageFactor);
					view.ASSETVIEW.ff_ageFactor.setText(Double.toString(ageFactor));
					
				}
			
				rs.close();
				select.close();
				DBEKMEANS.conn.close();
			
			} catch (SQLException | ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		else if(arg0.getSource() == view.ASSETVIEW.Filter){
			DBEKMEANS.LoadDriver();
			DBEKMEANS.TestConnection();
			try {
				String subCategoryList = "SELECT subcategory_name FROM tbl_subcategory S join tbl_category C on S.category_id = C.category_id  where category_name = ?";
		
				PreparedStatement select =  DBEKMEANS.conn.prepareStatement(subCategoryList);
			
				select.setString(1, ASSETVIEW.Filter.getSelectedItem().toString());
				ResultSet rs = select.executeQuery();
				ASSETVIEW.sbFilter.removeAllItems();
				ASSETVIEW.sbFilter.addItem("");
			
				while(rs.next()){
					ASSETVIEW.sbFilter.addItem(rs.getString("subcategory_name"));
				}
			
				rs.close();
				select.close();
				DBEKMEANS.conn.close();
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
