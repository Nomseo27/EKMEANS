package controller;

import javax.swing.event.ChangeEvent;

public class ChangeListener implements javax.swing.event.ChangeListener {

	@Override
	public void stateChanged(ChangeEvent arg0) {
		// TODO Auto-generated method stub
		
		String title = view.ASSETVIEW.system.getTitleAt(view.ASSETVIEW.system.getSelectedIndex());
		
		if(title.equals("Queries")){
			controller.QueryController query = new controller.QueryController();
			query.level();
			query.net();
			query.salvage();
		}
		
		else if(title.equals("Dashboard")){
			view.ASSETVIEW.dashBoardCenter.remove(chartController.chartPanel);
			@SuppressWarnings("unused")
			chartController chart = new chartController();
			view.ASSETVIEW.dashBoardCenter.repaint();
			view.ASSETVIEW.dashBoardCenter.validate();
			
			controller.dashboardController dashboard = new controller.dashboardController();
			dashboard.kConsistency();
			dashboard.eConsistency();
			dashboard.avgStat();
			
		}
		
			
		
	}

}
