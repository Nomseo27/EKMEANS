package controller;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class RowListener implements ListSelectionListener {

	@Override
	public void valueChanged(ListSelectionEvent arg0) {
		// TODO Auto-generated method stub
		if(arg0.getSource() == view.ASSETVIEW.dataTable.getSelectionModel()){
			try{
				int row = view.ASSETVIEW.dataTable.getSelectedRow();
				model.TBLASSET search = new model.TBLASSET();
				boolean asset = search.find(view.ASSETVIEW.dataTable.getValueAt(row, 0).toString());
				if(asset){
					view.ASSETVIEW.assetCodeField.setText(search.asset_code);
					view.ASSETVIEW.assetNameField.setText(search.assetName);
					DateFormat format = new SimpleDateFormat("yyyy-mm-dd", Locale.ENGLISH);
					Date date = new Date();
					try {
						date = format.parse(search.acqDate);
					} catch (ParseException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					view.ASSETVIEW.modelDate.setValue(date);;
					view.ASSETVIEW.lifeSpinner.getModel().setValue(search.life);
					view.ASSETVIEW.acqValueField.setText(Double.toString(search.acq_value));
					view.ASSETVIEW.salvageValueField.setText(Double.toString(search.salvage_value));
					view.ASSETVIEW.f_categoryField.setSelectedItem(search.categoryName);
					view.ASSETVIEW.f_subCategory.setSelectedItem(search.subCategoryName);
				}
			}
			
			catch(Exception e){
				e.printStackTrace();
			}
		}
		
		else if(arg0.getSource() == view.ASSETVIEW.categoryTB.getSelectionModel()){
			try{
				int row = view.ASSETVIEW.categoryTB.getSelectedRow();
				model.R_CATEGORY search = new model.R_CATEGORY();
				boolean asset = search.find(view.ASSETVIEW.categoryTB.getValueAt(row, 0).toString());
				if(asset){
					view.ASSETVIEW.categoryField.setText(search.category_name);
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		
		else if(arg0.getSource() == view.ASSETVIEW.factorTB.getSelectionModel()){
			try{
				int row = view.ASSETVIEW.factorTB.getSelectedRow();
				model.TBLASSET search = new model.TBLASSET();
				String id = view.ASSETVIEW.factorTB.getValueAt(row, 0).toString();
				boolean asset = search.find(id);
				System.out.println(view.ASSETVIEW.factorTB.getValueAt(row, 0).toString());
				if(asset){
					DateFormat format = new SimpleDateFormat("Y-M-d", Locale.ENGLISH);
					
					Date acqDate = format.parse(search.acqDate);
					int life = search.life;
					double depRate;
					double ageFactor;
					Date created = new Date();
					@SuppressWarnings("deprecation")
					int actualService = created.getYear() - acqDate.getYear();
					
					depRate = (double) (life - actualService) / life;
					System.out.println(depRate + " = " + "( " + life + " - " + actualService + ")/ " + life);
					//set the age Factor
					if(depRate > -1.0) 
						if(depRate > -0.90)
							if(depRate > -0.80)
								if(depRate > -0.70)
									if(depRate > -0.60)
										if(depRate > -0.50)
											if(depRate > -0.40)
												if(depRate > -0.30)
													if(depRate > -0.20)
														if(depRate > -0.10)
															if(depRate > -0.01)
																if(depRate != 0.0)
																	if(depRate >= 0.5) ageFactor = 0.900;
																	else ageFactor = depRate + 0.400;
																else ageFactor = 0.300;
															else ageFactor = 0.282;
														else ageFactor = 0.264;
													else ageFactor = 0.245;
												else ageFactor = 0.227;
											else ageFactor = 0.209;
										else ageFactor = 0.191;
									else ageFactor = 0.173;
								else ageFactor = 0.155;
							else ageFactor = 0.136;
						else ageFactor = 0.118;
					else ageFactor = 0.100;
					
					System.out.println(ageFactor);
					view.ASSETVIEW.factorTB.setValueAt(ageFactor, row, 3);
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		
		
		
		
		
			
	}
}


