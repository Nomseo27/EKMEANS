package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JOptionPane;

public class R_CATEGORY extends DBEKMEANS {
	
	public int category_id;
	public String category_name;
	
	public void setAttribute(String attributeName, String attribute){
		try{
			switch(attributeName){
			case "category_id":
				category_id = Integer.parseInt(attribute);
				break;
			case "category_name":
				category_name = attribute;
				break;
			}
		}
		catch(NumberFormatException NFE){
			NFE.printStackTrace();
		}
		
	}
	
	public boolean save(){
		view.ASSETVIEW.categoryTB.getSelectionModel().removeListSelectionListener(view.ASSETVIEW.table);
		
		TestConnection();
		int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to add this Category?");
		if(confirm == JOptionPane.NO_OPTION) return false;
		
		try{
			String save = "INSERT INTO tbl_category(category_name, deleted) VALUES(?, 0)";
			PreparedStatement statement = conn.prepareStatement(save);
			
			statement.setString(1, category_name);
			
			statement.executeUpdate();
			
			System.out.println("Successfully Inserted");
			JOptionPane.showMessageDialog(null, "Succcessfully Insterted");
			
			statement.close();
			conn.close();
			return true;
			
		}
		catch(Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage());
			return false;
		}
	}
	
	public boolean find(String category){
		TestConnection();
		
		try{
			String find = "SELECT C.* FROM tbl_category C WHERE category_name = ?";
			PreparedStatement select = conn.prepareStatement(find);
			
			select.setString(1, category);
			
			ResultSet rs = select.executeQuery();
			
			while(rs.next()){
				
				category_id = rs.getInt("category_id");
				category_name = rs.getString("category_name");
				return true;
			}
			
			rs.close();
			select.close();
			conn.close();
			
		}
		catch(Exception E){
			E.printStackTrace();
		}
		return false;
	}
	
	public void refresh(){
		view.ASSETVIEW.categoryTB.getSelectionModel().removeListSelectionListener(view.ASSETVIEW.table);
		
		int rowCount = view.ASSETVIEW.categoryModel.getRowCount();
		//Remove rows one by one from the end of the table
		for (int i = rowCount - 1; i >= 0; i--) {
			view.ASSETVIEW.categoryModel.removeRow(i);
		}
		
		TestConnection();
		try{
			String categoryDataTable = "SELECT category_name FROM tbl_category";
			PreparedStatement select3 = conn.prepareStatement(categoryDataTable);
			
			ResultSet rs3 = select3.executeQuery();
			
			while(rs3.next()){
				Object[] row = {rs3.getString("category_name")};
				view.ASSETVIEW.categoryModel.addRow(row);
			}
			
			rs3.close();
			select3.close();
			conn.close();
			
			view.ASSETVIEW.categoryTB.getSelectionModel().addListSelectionListener(view.ASSETVIEW.table);
		}
		catch(Exception E){
			E.printStackTrace();
		}
		
	}
	
	public void update(String categoryName, int id){
		TestConnection();
		
		try{
			String update = "UPDATE tbl_category SET category_name = ? WHERE category_id = ?";
			PreparedStatement statement = conn.prepareStatement(update);
			
			statement.setString(1, categoryName.toUpperCase());
			statement.setInt(2, id);
			
			statement.executeUpdate();
			
			System.out.println("Successfully Updated");
			JOptionPane.showMessageDialog(null, "SuccessfullyUpdated");
			
			statement.close();
			conn.close();
		}
		catch(Exception E){
			E.printStackTrace();
			JOptionPane.showMessageDialog(null, E.getMessage());
		}
	}
	
	public void delete(){
		TestConnection();
		try{
			String delete = "UPDATE tbl_category SET deleted = 1 WHERE category_name = ?";
			PreparedStatement statement = conn.prepareStatement(delete);
			
			statement.setString(1, category_name);
			
			statement.executeUpdate();
			
			System.out.println("Successfully Deleted");
			JOptionPane.showMessageDialog(null, "Successfully Deleted");
			
			statement.close();
			conn.close();
			
			refresh();
		}
		catch(Exception E){
			E.printStackTrace();
		}
	}
	
	
	
	
	

}
