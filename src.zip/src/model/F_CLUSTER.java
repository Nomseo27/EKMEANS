package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class F_CLUSTER extends DBEKMEANS{
	
	public String asset_code;
	public int cluster_id;
	public int factor_id;
	public double ageFactor;
	public double usageFactor;
	public int cluster;
	
	public void setAttribute(String attribute, String value){
		
		switch(attribute){
		case "asset_code":
			asset_code = value;
			break;
		case "cluster_id":
			cluster_id = Integer.parseInt(value);
			break;
		case "ageFactor":
			ageFactor = Double.parseDouble(value);
			break;
		case "usageFactor":
			usageFactor = Double.parseDouble(value);
			break;
		case "cluster":
			cluster = Integer.parseInt(value);
			break;
		}
	}
	
	public void save(){
		TestConnection();
		try{
			String select_factor = "SELECT factor_id FROM tbl_factor WHERE asset_code = ?";
			PreparedStatement ps = conn.prepareStatement(select_factor);
			
			ps.setString(1, asset_code);
			
			System.out.println(asset_code);
			System.out.println(ageFactor);
			System.out.println(usageFactor);
			
			ResultSet rset = ps.executeQuery();
			
			if(rset.next()) factor_id = rset.getInt("factor_id");
			
			System.out.println(factor_id);
			rset.close();
			conn.close();
			
			TestConnection();
			
			String sql = "INSERT INTO tbl_cluster_detail(factor_id, cluster_id, cluster)VALUES(?,?,?)";
			PreparedStatement statement = conn.prepareStatement(sql);
			
			
			statement.setInt(1, factor_id);
			statement.setInt(2, cluster_id);
			statement.setInt(3, cluster);
			
			statement.executeUpdate();
			
			System.out.println("successfully inserted to f_cluster");
			
			conn.close();
			statement.close();
			
		}
		catch(Exception e){
			e.printStackTrace();
			System.out.println(e.getMessage());
			return;
		}
	}
	
	public void deleteAll(){
		TestConnection();
		try{
			String sql = "DELETE FROM tbl_cluster";
			PreparedStatement statement = conn.prepareStatement(sql);
			
			statement.executeUpdate();
			
			conn.close();
			statement.close();
			
			
		}
		catch(Exception e){
			e.printStackTrace();
			return;
		}
	}
}
