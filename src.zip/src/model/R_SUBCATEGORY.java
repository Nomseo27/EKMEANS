package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JOptionPane;

public class R_SUBCATEGORY extends DBEKMEANS {
	
	public int category_id;
	public String category_name;
	public int subcategory_id;
	public String subcategory_name;
	
	public void setAttribute(String attributeName, String attribute){
		try{
			switch(attributeName){
			case "category_id":
				category_id = Integer.parseInt(attribute);
				break;
			case "subcategory_id":
				subcategory_id = Integer.parseInt(attribute);
				break;
			case "category_name":
				category_name = attribute;
				break;
			case "subcategory_name":
				subcategory_name = attribute;
				break;
			}
		}
		catch(NumberFormatException NFE){
			NFE.printStackTrace();
		}
		
	}
	
	public void save(){
		view.ASSETVIEW.categoryTB.getSelectionModel().removeListSelectionListener(view.ASSETVIEW.table);
		
		TestConnection();
		int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to add this Asset?");
		if(confirm == JOptionPane.NO_OPTION) return;
		
		try{
			
			String save2 = "SELECT category_id FROM tbl_category WHERE category_name = ?";
			PreparedStatement statement2 = conn.prepareStatement(save2);
			
			statement2.setString(1, category_name);
			
			ResultSet rs = statement2.executeQuery();
			if(rs.next()) category_id = rs.getInt("category_id");
			
			statement2.close();
			rs.close();
			conn.close();
			
			TestConnection();
			
			String save1 = "INSERT INTO tbl_subcategory(subcategory_name, category_id, deleted) VALUES(?,?, 0)";
			PreparedStatement statement1 = conn.prepareStatement(save1);
			
			statement1.setString(1, subcategory_name);
			statement1.setInt(2, category_id);
			
			statement1.executeUpdate();
			
			System.out.println("Successfully Inserted");
			JOptionPane.showMessageDialog(null, "Succcessfully Insterted");
			
			statement1.close();
			conn.close();
			
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public boolean find(String category, String subcategory){
		TestConnection();
		
		try{
			String find = "SELECT C.*, S.subcategory_name, S.subcategory_id FROM tbl_category C join tbl_subcategory S on C.category_id =  S.category_id WHERE category_name = ? AND subcategory_name = ?";
			PreparedStatement select = conn.prepareStatement(find);
			
			select.setString(1, category);
			select.setString(2, subcategory);
			
			ResultSet rs = select.executeQuery();
			
			while(rs.next()){
				
				category_id = rs.getInt("category_id");
				category_name = rs.getString("category_name");
				subcategory_id = rs.getInt("subcategory_id");
				subcategory_name = rs.getString("subcategory_name");
				return true;
			}
			
			rs.close();
			select.close();
			conn.close();
			
		}
		catch(Exception E){
			E.printStackTrace();
		}
		return false;
	}
	
	public void refresh(){
		view.ASSETVIEW.subcategoryTB.getSelectionModel().removeListSelectionListener(view.ASSETVIEW.table);
		
		int rowCount = view.ASSETVIEW.categoryModel.getRowCount();
		//Remove rows one by one from the end of the table
		for (int i = rowCount - 1; i >= 0; i--) {
			view.ASSETVIEW.subcategoryModel.removeRow(i);
		}
		
		TestConnection();
		try{
			String categoryDataTable = "SELECT category_name, subcategory_name FROM tbl_category C join tbl_subcategory S on C.category_id = S.category_id ";
			PreparedStatement select3 = conn.prepareStatement(categoryDataTable);
			
			ResultSet rs3 = select3.executeQuery();
			
			while(rs3.next()){
				Object[] row = {rs3.getString("category_name"), rs3.getString("subcategory_name")};
				view.ASSETVIEW.subcategoryModel.addRow(row);
			}
			
			rs3.close();
			select3.close();
			conn.close();
			
			view.ASSETVIEW.subcategoryTB.getSelectionModel().addListSelectionListener(view.ASSETVIEW.table);
		}
		catch(Exception E){
			E.printStackTrace();
		}
		
	}
	
	public void update(String categoryName, String sub, int id, int id2){
		TestConnection();
		
		try{
			String update = "UPDATE tbl_category SET category_name = ? WHERE category_id = ?";
			PreparedStatement statement = conn.prepareStatement(update);
			
			statement.setString(1, categoryName.toUpperCase());
			statement.setInt(2, id);
			
			statement.executeUpdate();
			
			System.out.println("Successfully Updated");
			JOptionPane.showMessageDialog(null, "SuccessfullyUpdated");
			
			statement.close();
			conn.close();
			TestConnection();
			
			String update1 = "UPDATE tbl_subcategory SET subcategory_name = ? WHERE subcategory_id = ?";
			PreparedStatement statement1 = conn.prepareStatement(update1);
			
			statement1.setString(1, sub.toUpperCase());
			statement1.setInt(2, id2);
			
			statement1.executeUpdate();
			
			System.out.println("Successfully Updated");
			JOptionPane.showMessageDialog(null, "SuccessfullyUpdated");
			
			statement1.close();
			conn.close();
		}
		catch(Exception E){
			E.printStackTrace();
		}
	}
	
	public void delete(){
		TestConnection();
		try{
			String delete = "UPDATE tbl_category SET deleted = 1 WHERE category_name = ?";
			PreparedStatement statement = conn.prepareStatement(delete);
			
			statement.setString(1, category_name);
			
			statement.executeUpdate();
			
			System.out.println("Successfully Deleted");
			JOptionPane.showMessageDialog(null, "Successfully Deleted");
			
			statement.close();
			conn.close();
			
			String delete1 = "UPDATE tbl_subcategory SET deleted = 1 WHERE subcategory_name = ?";
			PreparedStatement statement1 = conn.prepareStatement(delete1);
			
			statement1.setString(1, subcategory_name);
			
			statement1.executeUpdate();
			
			System.out.println("Successfully Deleted");
			JOptionPane.showMessageDialog(null, "Successfully Deleted");
			
			statement1.close();
			conn.close();
			
			refresh();
		}
		catch(Exception E){
			E.printStackTrace();
		}
	}
	
	
	
	
	

}
