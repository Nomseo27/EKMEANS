package model;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

@SuppressWarnings("unused")
public class DBEKMEANS {
	//connection 
	public static Connection conn = null;
	TBLASSET fixedAsset;
	
	public static void LoadDriver(){
		try{
			//mysql Driver
			Class.forName("com.mysql.jdbc.Driver").newInstance();		
			System.out.println("Loaded Driver");
		}
		catch(Exception e){
			//handle error]
			System.out.println(e.getMessage());
		}
		
	}
	
	public static void TestConnection(){
		try{
			//connection 
			String url = "jdbc:mysql://localhost:3306/dbekmeans_oltp";
			String username = "root";
			String password = "";
			
			conn = DriverManager.getConnection(url, username, password);
			
			System.out.println("Connection Successful");
			
		}
		catch(Exception e){
			//handle error
			e.printStackTrace();
		}
	}
}
