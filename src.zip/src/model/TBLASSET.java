package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.Date;

import javax.swing.JOptionPane;

import view.ASSETVIEW;

public class TBLASSET extends DBEKMEANS{
	public String asset_code;
	public String assetName;
	public int category;
	public String categoryName;
	public String subCategoryName;
	public double depRate;
	public String acqDate;
	public int life;
	public int actualService;
	public double acq_value;
	public double salvage_value;
	public String created;
	public String updated;
	//constructor1
	
	public void setAttribute(String attributeName, String attribute){
		try{
			switch(attributeName){
			case "depRate":
				double converted = Double.parseDouble(attribute);
				depRate = converted;
				break;
			case  "life":
				int convert = Integer.parseInt(attribute);
				life = convert;
				break;
			
			case "actualService": 
				int convert2 = Integer.parseInt(attribute);
				actualService = convert2;
				break;
			case "acq_value":
				double convert3 = Double.parseDouble(attribute);
				acq_value = convert3;
				break;
			case "salvage_value":
				double convert4 = Double.parseDouble(attribute);
				salvage_value = convert4;
				break;
			case "asset_code":
				asset_code=attribute;
				break;
			case "asset_name":
				assetName=attribute;
				break;
			case "acqDate":
				acqDate=attribute;
				break;
			case "created":
				created=attribute;
				break;
			case "updated":
				updated=attribute;
				break;
			case "category":
				category=Integer.parseInt(attribute);
				break;
			case "category_name":
				categoryName = attribute;
				break;
			case "subcategory_name":
				subCategoryName = attribute;
				break;
			}
		}
		catch(NumberFormatException e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage() );
		}
	}
	
	public void save() {
		TestConnection();
		
		ASSETVIEW.dataTable.getSelectionModel().removeListSelectionListener(ASSETVIEW.table);
		
		
		int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to add this Asset?");
		if(confirm == JOptionPane.NO_OPTION) return;
		
		if(ASSETVIEW.f_categoryField.getSelectedItem().toString() != null) 
			if(ASSETVIEW.f_subCategory.getSelectedItem().toString() != null) System.out.print("good");
			else {
					JOptionPane.showConfirmDialog(null, "Undefined Sub Category");
					return;
			}
		else {
			JOptionPane.showConfirmDialog(null, "Undefined Category");
			return;
		}
			
		

		try {
		
		String getCategory = "SELECT subcategory_id FROM tbl_category C join tbl_subcategory S on C.category_id = S.category_id WHERE category_name = ? and subcategory_name = ?";
		PreparedStatement setCategory = conn.prepareStatement(getCategory);
		
		setCategory.setString(1, categoryName);
		setCategory.setString(2, subCategoryName);
		
		ResultSet rs=setCategory.executeQuery();
		if(rs.next()) category = rs.getInt("subcategory_id");
		
		rs.close();
		setCategory.close();
		conn.close();
		System.out.println(category);
		System.out.println(categoryName);
		System.out.println(subCategoryName);
		TestConnection();
		
		String sql = "INSERT INTO tbl_asset(asset_code,fixedAssetName, asset_category, acq_date, acq_value, salvage_value, service_life)VALUES(?,?,?,?,?,?,?)";
		PreparedStatement statement = conn.prepareStatement(sql);
		
		statement.setString(1, asset_code);
		statement.setString(2, assetName);
		statement.setInt(3, category);
		statement.setString(4, acqDate);
		statement.setDouble(5, acq_value);
		statement.setDouble(6, salvage_value);
		statement.setInt(7, life);
		statement.executeUpdate();
		
		JOptionPane.showMessageDialog(null, "Successfully Added");
		
		DecimalFormat df = new DecimalFormat("0.000"); 
		
		Object[] row = {asset_code, assetName, acqDate , df.format(acq_value), df.format(salvage_value), df.format(salvage_value) , life};
		view.ASSETVIEW.model.addRow(row);
		conn.close();
		statement.close();
		refresh();
		ASSETVIEW.dataTable.getSelectionModel().addListSelectionListener(ASSETVIEW.table);
		
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, e1.getMessage() );
		}
		
		
	}
	
	public boolean find(String propertyNo){
		TestConnection();
		try{
			String sql = "SELECT * FROM tbl_asset WHERE asset_code like ? AND disposed is null";
			PreparedStatement select = conn.prepareStatement(sql);
			select.setString(1, "%" + propertyNo + "%");
			
			ResultSet rs = select.executeQuery();
			
			while(rs.next()){
				asset_code = rs.getString("asset_code");
				assetName = rs.getString("fixedAssetName");
				category = rs.getInt("asset_category");
				acqDate = rs.getDate("acq_date").toString();
				life = rs.getInt("service_life");
				acq_value = rs.getDouble("acq_value");
				salvage_value = rs.getDouble("salvage_value");
				
				String stmt = "SELECT category_name, subcategory_name FROM tbl_category C join tbl_subcategory S on C.category_id = S.category_id WHERE S.subcategory_id = ?";
				PreparedStatement ps = conn.prepareStatement(stmt);
				ps.setInt(1, category);
				ResultSet rs1 = ps.executeQuery();
				
				if(rs1.next()){
					categoryName = rs1.getString("category_name");
					subCategoryName = rs1.getString("subcategory_name");
				}
				
				rs1.close();
				ps.close();
				return true;
			}
			conn.close();
			select.close();
			rs.close();
		}
		catch(Exception e){
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		
		return false;
		
	}
	
	public void dispose(String propertyNo){
		TestConnection();
		int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to dispose this Asset?");
		if(confirm == JOptionPane.NO_OPTION) return;

		try {
			
		String sql = "UPDATE tbl_asset SET disposed = 1 WHERE asset_code = ?";
		PreparedStatement statement = conn.prepareStatement(sql);
		
		statement.setString(1, propertyNo);
		statement.executeUpdate();
		
		conn.close();
		statement.close();
		
		refresh();
		
		JOptionPane.showMessageDialog(null, "Successfully Disposed");
		
		} catch (Exception e1) {
			JOptionPane.showMessageDialog(null, e1.getMessage() );
		}
		
		
	}
	
	public static void refresh(){
		
		ASSETVIEW.dataTable.getSelectionModel().removeListSelectionListener(ASSETVIEW.table);
		
		int rowCount = view.ASSETVIEW.model.getRowCount();
		int rowCount2 = view.ASSETVIEW.factorModel.getRowCount();
		//Remove rows one by one from the end of the table
		for (int i = rowCount - 1; i >= 0; i--) {
			view.ASSETVIEW.model.removeRow(i);
		}
		
		for (int i = rowCount2 - 1; i >= 0; i--) {
			view.ASSETVIEW.factorModel.removeRow(i);
		}
		
		TestConnection();
		try{
			String sql = "SELECT * FROM tbl_asset WHERE disposed IS NULL";
			PreparedStatement select = DBEKMEANS.conn.prepareStatement(sql);
			
			ResultSet rs = select.executeQuery();
			
			while(rs.next()){
				String asset_code = rs.getString("asset_code");
				String assetName = rs.getString("fixedAssetName");
				Date acqDate = rs.getDate("acq_date");
				int life = rs.getInt("service_life");
				double acqValue = rs.getDouble("acq_value");
				double salvageValue = rs.getDouble("salvage_value");
				
				DecimalFormat df = new DecimalFormat("0.000"); 

				
				Object[] row = {asset_code, assetName, acqDate, df.format(acqValue), df.format(salvageValue), life};
				view.ASSETVIEW.model.addRow(row);
				
			}
			conn.close();
			rs.close();
			select.close();
			
			ASSETVIEW.dataTable.getSelectionModel().addListSelectionListener(ASSETVIEW.table);
			
			TestConnection();
			try{
				String factor =  "SELECT tbl_asset.asset_code, fixedAssetName, usage_factor, age_factor FROM tbl_asset left join tbl_factor on tbl_asset.asset_code = tbl_factor.asset_code WHERE tbl_asset.disposed IS NULL";
				PreparedStatement ps = conn.prepareStatement(factor);
				
				ResultSet rs2 = ps.executeQuery();
				
				while(rs2.next()){
					String ac = rs2.getString("asset_code");
					String an = rs2.getString("fixedAssetName");
					double uf = rs2.getDouble("usage_factor");
					double af = rs2.getDouble("age_factor");
					
					DecimalFormat df2 = new DecimalFormat("0.000"); 
					
					Object[] row2 = {ac, an, df2.format(uf), df2.format(af)};
					ASSETVIEW.factorModel.addRow(row2);
				}
				
				rs2.close();
				ps.close();
				conn.close();
				
			}
			catch(Exception E){
				E.printStackTrace();
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	public void update(){
		TestConnection();
		int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to update this Asset?");
		if(confirm == JOptionPane.NO_OPTION) return;

		try {
		
		String getCategory = "SELECT subcategory_id FROM tbl_category C join tbl_subcategory S on C.category_id = S.category_id WHERE category_name = ? and subcategory_name = ?";
		PreparedStatement setCategory = conn.prepareStatement(getCategory);
			
		setCategory.setString(1, categoryName);
		setCategory.setString(2, subCategoryName);
			
		ResultSet rs=setCategory.executeQuery();
		if(rs.next()) category = rs.getInt("subcategory_id");
			
		rs.close();
		setCategory.close();
		conn.close();
		System.out.println(category);
		System.out.println(categoryName);
		System.out.println(subCategoryName);
		TestConnection();
			
		String sql = "UPDATE tbl_asset set fixedAssetName= ?, asset_category=?, acq_date= ?, service_life= ?, acq_value= ?, salvage_value = ?  WHERE asset_code= ?";
		PreparedStatement statement = conn.prepareStatement(sql);
		
		statement.setString(1, assetName);
		statement.setInt(2, category);
		statement.setString(3, acqDate);
		statement.setInt(4, life);
		statement.setDouble(5, acq_value);
		statement.setDouble(6, salvage_value);
		statement.setString(7, asset_code);
		statement.executeUpdate();
		
		JOptionPane.showMessageDialog(null, "Successfully Updated");
	
		refresh();
		conn.close();
		statement.close();
		
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			JOptionPane.showMessageDialog(null, e1.getMessage() );
		}
		
		
		
		
	}
	
}
