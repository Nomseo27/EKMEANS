package view;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Loading extends JFrame implements ActionListener {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public JProgressBar progressbar;
	public JLabel message;
	public JButton button;
	public JPanel okPanel;
	JPanel messagePanel;
	
	
	public Loading(){
		setLayout(new BorderLayout());
		
		progressbar =  new JProgressBar(0, 100);
		progressbar.setValue(0);
		message = new JLabel();
		message.setText("Clustering Asset. Don't Close the Software");
		okPanel = new JPanel();
		messagePanel = new JPanel();
		
		button = new JButton("FINISH");
		button.setEnabled(false);
		button.addActionListener(this);
		
		messagePanel.add(message);
		okPanel.add(button);
		
		add(messagePanel, BorderLayout.NORTH);
		add(okPanel, BorderLayout.SOUTH);
	
		
		add(progressbar, BorderLayout.CENTER);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setSize(400, 125);
		setLocationRelativeTo(null);
		setVisible(true);
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == button){
			this.dispose();
		}
	}
}
