package view;

import javax.swing.JFrame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

@SuppressWarnings("serial")
public class WELCOMEVIEW extends JFrame implements ActionListener {
	JButton Button;
	
	public WELCOMEVIEW(){
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		//JLabel WelcomeLabel = new JLabel("WELCOME to Fixed Asset Monitoring System");
		// Import ImageIcon     
		ImageIcon iconLogo = new ImageIcon(getClass().getResource("welcomeFAMS.jpg") );
		// In init() method write this code
		JLabel version = new JLabel();
		version.setIcon(iconLogo);
		//WelcomeLabel.setHorizontalAlignment(JLabel.CENTER);
		//version.setHorizontalAlignment(JLabel.CENTER);
		//WelcomeLabel.setFont(new Font("Segoe UI Light", Font.PLAIN,20));
		Button = new JButton("Continue");
		//setLayout(new BorderLayout());
		//center.add(WelcomeLabel);
		//center.add(version);
		panel.add(version, BorderLayout.CENTER);
		panel.add(Button, BorderLayout.SOUTH);
		getRootPane().setBorder(BorderFactory.createMatteBorder(
                2, 5, 2, 2, Color.RED));
		setContentPane(panel);
		getContentPane().setBackground(Color.WHITE);
		setSize(800, 400);
		setLocationRelativeTo(null);
		setUndecorated(true);
		setVisible(true);
		
		
		Button.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		//setVisible(false);
		this.dispose();
	}
	
}
