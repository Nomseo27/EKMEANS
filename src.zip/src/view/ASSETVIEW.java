package view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.*;
import org.jdatepicker.impl.*;
import java.beans.PropertyChangeListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.beans.PropertyChangeEvent;

import model.*;

public class ASSETVIEW implements PropertyChangeListener{
	
	//attributes of view
	JFrame assetView;
	JPanel maintenance;
	JPanel form;
	JPanel cluster;
	JPanel utility;
	JPanel category_panel;
	JPanel button_SC_panel;
	JPanel subcategory_panel;
	JPanel subcategory_panel_north;
	JPanel factor_panel;
	JPanel factor_form;
	JPanel factor_button;
	SpringLayout layout2;
	JPanel factor_form2;
	JPanel cluster_form;
	JPanel factor_main;
	JPanel kmeans_panel;
	SpringLayout layout3;
	
	//form components
	JLabel formName;
	JLabel assetCodeFieldLabel;
	public static JTextField assetCodeField;
	JLabel assetNameFieldLabel;
	public static JTextField assetNameField;
	JLabel depRateFieldLabel;
	public static JTextField depRateNameField;
	JLabel acqDateFieldLabel;
	public static UtilDateModel modelDate;
	public static JDatePanelImpl datePanel;
	public static JDatePickerImpl datePicker;
	Properties p;
	JLabel lifeFieldLabel;
	SpinnerModel numberSpin;
	public static JSpinner lifeSpinner;
	JLabel acqValueFieldLabel;
	double acq;
	public static JFormattedTextField acqValueField;
	JLabel salvageValueFieldLabel;
	double salvage;
	public static JFormattedTextField salvageValueField;
	NumberFormat amountFormat;
	
	public static JComboBox<String> f_categoryField;
	JLabel f_categoryLabel;
	JLabel f_subCategoryLabel;
	public static JComboBox<String> f_subCategory;
	
	public static JTabbedPane system;
	
	
	//form center panel
	JPanel centerForm;
	SpringLayout layout;
	
	//cluster components
	JLabel clusterName;
	public static JTable dataTable;
	String[] columnNames;
	Object[][] ColumnData;
	public static DefaultTableModel model;
	
	//buttons
	JPanel buttonPanel;
	public static JButton addButton;
	public static JButton clearButton;
	public static JButton deleteButton;
	public static JButton searchButton;
	public static JButton editButton;
	public static JButton updateButton;
	
	//TRANSACTION FORMS
	JPanel transaction;
	public static JProgressBar progressBar;

	public static JTable clusterTable;
	String[] names;
	Object[][] data;
	public static DefaultTableModel clusterModel;
	
	public static JButton clusterButton;
	
	//Utility
	JPanel utilityNorth;
	JPanel utilitySouth;
	public static JTextField categoryField;
	JLabel categoryLabel;
	JLabel subCategoryLabel;
	public static JTextField subCategory;
	public static JTable categoryTB;
	String[] c_name;
	Object[][] c_data;
	public static DefaultTableModel categoryModel;
	
	public static JTable subcategoryTB;
	String[] sc_name;
	Object[][] sc_data;
	public static DefaultTableModel subcategoryModel;
	
	//subcategory_panel
	public static JComboBox<String> CB_category;
	public JLabel cb_categoryLabel;
	
	public static JButton c_Save;
	public static JButton c_Edit;
	public static JButton c_Update;
	public static JButton c_Delete;
	
	public static JButton s_Save;
	public static JButton s_Edit;
	public static JButton s_Update;
	public static JButton s_Delete;
	
	 //listeners
	public static controller.ButtonListener controll;
	public static controller.RowListener table;
	public static controller.DropDownListener CB;
	public static controller.ChangeList focus;
	public static controller.ChangeListener tab;
	
	//factor panel objects
	/*double use;
	public static JFormattedTextField usageFactorField;
	JLabel usageFactorFieldLabel;
	double age;
	public static JFormattedTextField ageFactorField;
	*/
	
	public static JTable factorTB;
	String[] f_name;
	Object[][] f_data;
	public static DefaultTableModel factorModel;
	public static JButton fb_Save;
	
	//factor form 
	JLabel f_formName;
	JLabel f_assetCodeFieldLabel;
	public static JComboBox<String> f_assetCodeField;
	JLabel f_assetNameFieldLabel;
	public static JTextField f_assetNameField;
	JLabel f_depRateFieldLabel;
	public static JTextField f_depRateNameField;
	JLabel f_acqDateFieldLabel;
	public static JTextField f_date;
	JLabel f_lifeFieldLabel;
	SpinnerModel f_numberSpin;
	public static JSpinner f_lifeSpinner;
	JLabel f_acqValueFieldLabel;
	public static JTextField f_acqValueField;
	JLabel f_salvageValueFieldLabel;
	public static JTextField f_salvageValueField;
	public static JTextField ff_category;
	JLabel ff_categoryLabel;
	public static JTextField ff_subcategory;
	JLabel ff_subcategoryLabel;
	
	JLabel ff_usageLabel;
	public static JTextField ff_usageFactor;
	JLabel ff_ageLabel;
	public static JTextField ff_ageFactor;
	
	//kmeans panel
	public static JComboBox<String> algorithm;
	public static JComboBox<String> k_subCategoryField;
	JLabel algorithmLabel;
	JLabel subLabel;
	
	//View Report
	
	public static JTabbedPane QueryForm;
	JPanel levelCenterPanel;
	JPanel levelMainPanel;
	JPanel levelNorthPanel;
	JPanel netMainPanel;
	JPanel netCenterPanel;
	JPanel salvageMainPanel;
	JPanel salvageCenterPanel;
	
	JLabel levelLabel;
	JLabel netLabel;
	JLabel salvageLabel;
	
	
	public JLabel cFilterLabel;

	public static JComboBox<String> Filter;
	public static JButton filterButton;
	
	public JLabel sbFilterLabel;
	public static JComboBox<String> sbFilter;
		
	public static JTable levelTB ;
	String[] levelName;
	Object[][] levelData;
	public static DefaultTableModel levelModel;
	
	public static JTable netTB ;
	String[] netName;
	Object[][] netData;
	public static DefaultTableModel netModel;
	
	public static JTable salvageTB ;
	String[] salvageName;
	Object[][] salvageData;
	public static DefaultTableModel salvageModel;
	
	//dashboard
	
	JPanel dashboard;
	JPanel dashboardNorth;
	public static JPanel dashBoardCenter;
	JPanel dashBoardSouth;
	JPanel kConsistency;
	JPanel eConsistency;
	JPanel kAveSpeed;
	JPanel eAveSpeed;
	JPanel kAveIter;
	JPanel eAveIter;
	
	JLabel kConLabel;
	JLabel eConLabel;
	JLabel kAveSpeedLabel;
	JLabel eAveSpeedLabel;
	JLabel kAveIterLabel;
	JLabel eAveIterLabel;
	
	public static JLabel kConValue;
	public static JLabel eConValue;
	public static JLabel kAveSpeedValue;
	public static JLabel eAveSpeedValue;
	public static JLabel kAveIterValue;
	public static JLabel eAveIterValue;
	
	//indiv result 
	public static JPanel indivMain;
	public static JPanel indivNorth;
	public static JPanel indivCenter;
	public static JPanel iKMain;
	public static JPanel iKNorth;
	public static JPanel iKCenter;
	public static JPanel iEMain;
	public static JPanel iENorth;
	public static JPanel iECenter;
	
	public static JComboBox<String> listAsset;
	public JLabel listAsssetLabel;
	public static JButton indivButton;
	
	public static JLabel kMeanTitle;
	public static JLabel kMeanAsset;
	public static JLabel kMeanLevel;
	public static JLabel kMeanIteration;
	public static JLabel kMeanBatch;
	
	public static JLabel eKMeanTitle;
	public static JLabel eKMeanAsset;
	public static JLabel eKMeanLevel;
	public static JLabel eKMeanIteration;
	public static JLabel eKMeanBatch;
	
	
	public JLabel dashFilterLabel;

	public static JComboBox<String> dashFilterCB;
	public static JButton dashFilterButton;
	
	JPanel dashNorthPanel;
	JPanel dashFilterPanel;
	JPanel dashConsPanel;
	
	
	
	ASSETVIEW(){
		
		try {
			// Set System L&F
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} 
		catch (UnsupportedLookAndFeelException e) {
			// handle exception
		}
		catch (ClassNotFoundException e) {
			// handle exception
		}
		catch (InstantiationException e) {
			// handle exception
		}
		catch (IllegalAccessException e) {
			// handle exception
		}

		
		
		//initiate components
		initiate();
		//form panel
		form.add(formName, BorderLayout.NORTH);
		form.add(centerForm, BorderLayout.CENTER);
		
		buttonPanel.add(addButton, BorderLayout.SOUTH);
		buttonPanel.add(clearButton, BorderLayout.SOUTH);
		buttonPanel.add(deleteButton, BorderLayout.SOUTH);
		buttonPanel.add(searchButton, BorderLayout.SOUTH);
		buttonPanel.add(editButton, BorderLayout.SOUTH);
		buttonPanel.add(updateButton, BorderLayout.SOUTH);
		
		form.add(buttonPanel, BorderLayout.SOUTH);
		//form Components
		centerForm.add(assetCodeFieldLabel);
		centerForm.add(assetCodeField);
		centerForm.add(assetNameFieldLabel);
		centerForm.add(assetNameField);
		centerForm.add(f_categoryLabel);
		centerForm.add(f_categoryField);
		centerForm.add(f_subCategoryLabel);
		centerForm.add(f_subCategory);
		centerForm.add(acqDateFieldLabel);
		centerForm.add(datePicker);
		centerForm.add(lifeFieldLabel);
		centerForm.add(lifeSpinner);
		centerForm.add(acqValueFieldLabel);
		centerForm.add(acqValueField);
		centerForm.add(salvageValueFieldLabel);
		centerForm.add(salvageValueField);
		//layout on Form4
		layout.putConstraint(SpringLayout.WEST, assetCodeFieldLabel, 10, SpringLayout.WEST, centerForm);
		layout.putConstraint(SpringLayout.NORTH, assetCodeFieldLabel, 10, SpringLayout.NORTH, centerForm);
		layout.putConstraint(SpringLayout.WEST, assetCodeField, 35, SpringLayout.EAST, assetCodeFieldLabel);
		layout.putConstraint(SpringLayout.NORTH, assetCodeField, 10, SpringLayout.NORTH, centerForm);
		
		layout.putConstraint(SpringLayout.WEST, assetNameFieldLabel, 10, SpringLayout.WEST, centerForm);
		layout.putConstraint(SpringLayout.NORTH, assetNameFieldLabel, 25, SpringLayout.SOUTH, assetCodeFieldLabel);
		layout.putConstraint(SpringLayout.WEST, assetNameField, 100, SpringLayout.EAST, assetNameFieldLabel);
		layout.putConstraint(SpringLayout.NORTH, assetNameField, 20, SpringLayout.SOUTH, assetCodeField);
		
		layout.putConstraint(SpringLayout.WEST, f_categoryLabel, 10, SpringLayout.WEST, centerForm);
		layout.putConstraint(SpringLayout.NORTH, f_categoryLabel, 25, SpringLayout.SOUTH, assetNameFieldLabel);
		layout.putConstraint(SpringLayout.WEST, f_categoryField, 83, SpringLayout.EAST, f_categoryLabel);
		layout.putConstraint(SpringLayout.NORTH, f_categoryField, 20, SpringLayout.SOUTH, assetNameField);
		
		layout.putConstraint(SpringLayout.WEST, f_subCategoryLabel, 10, SpringLayout.WEST, centerForm);
		layout.putConstraint(SpringLayout.NORTH, f_subCategoryLabel, 25, SpringLayout.SOUTH, f_categoryLabel);
		layout.putConstraint(SpringLayout.WEST, f_subCategory, 63, SpringLayout.EAST, f_subCategoryLabel);
		layout.putConstraint(SpringLayout.NORTH, f_subCategory, 20, SpringLayout.SOUTH, f_categoryField);
		
		layout.putConstraint(SpringLayout.WEST, acqDateFieldLabel, 10, SpringLayout.WEST, centerForm);
		layout.putConstraint(SpringLayout.NORTH, acqDateFieldLabel, 25, SpringLayout.SOUTH, f_subCategoryLabel);
		layout.putConstraint(SpringLayout.WEST, datePicker, 110, SpringLayout.EAST, acqDateFieldLabel);
		layout.putConstraint(SpringLayout.NORTH, datePicker, 20, SpringLayout.SOUTH, f_subCategory);
		
		layout.putConstraint(SpringLayout.WEST, lifeFieldLabel, 10, SpringLayout.WEST, centerForm);
		layout.putConstraint(SpringLayout.NORTH, lifeFieldLabel, 25, SpringLayout.SOUTH, acqDateFieldLabel);
		layout.putConstraint(SpringLayout.WEST, lifeSpinner, 132, SpringLayout.EAST, lifeFieldLabel);
		layout.putConstraint(SpringLayout.NORTH, lifeSpinner, 20, SpringLayout.SOUTH, datePicker);
		
		layout.putConstraint(SpringLayout.WEST, acqValueFieldLabel, 10, SpringLayout.WEST, centerForm);
		layout.putConstraint(SpringLayout.NORTH, acqValueFieldLabel, 25, SpringLayout.SOUTH, lifeFieldLabel);
		layout.putConstraint(SpringLayout.WEST, acqValueField, 100, SpringLayout.EAST, acqValueFieldLabel);
		layout.putConstraint(SpringLayout.NORTH, acqValueField, 20, SpringLayout.SOUTH, lifeSpinner);
		
		layout.putConstraint(SpringLayout.WEST, salvageValueFieldLabel, 10, SpringLayout.WEST, centerForm);
		layout.putConstraint(SpringLayout.NORTH, salvageValueFieldLabel, 25, SpringLayout.SOUTH, acqValueFieldLabel);
		layout.putConstraint(SpringLayout.WEST, salvageValueField, 117, SpringLayout.EAST, salvageValueFieldLabel);
		layout.putConstraint(SpringLayout.NORTH, salvageValueField, 20, SpringLayout.SOUTH, acqValueField);
		
		//utility frame
		
		utilityNorth.add(categoryLabel);
		utilityNorth.add(categoryField);
		category_panel.add(utilityNorth, BorderLayout.NORTH);
		category_panel.add(new JScrollPane(categoryTB), BorderLayout.CENTER);
		utilitySouth.add(c_Save);
		category_panel.add(utilitySouth, BorderLayout.SOUTH);
		
		//sub_category
		subcategory_panel_north.add(cb_categoryLabel);
		subcategory_panel_north.add(CB_category);
		subcategory_panel_north.add(subCategoryLabel);
		subcategory_panel_north.add(subCategory);
		
		button_SC_panel.add(s_Save);
		
		subcategory_panel.add(subcategory_panel_north, BorderLayout.NORTH);
		subcategory_panel.add(new JScrollPane(subcategoryTB), BorderLayout.CENTER);
		subcategory_panel.add(button_SC_panel, BorderLayout.SOUTH);
	
		
		utility.add(category_panel);
		utility.add(subcategory_panel);
		
		//cluster components
		cluster.add(clusterName, BorderLayout.NORTH);
		cluster.add(new JScrollPane(dataTable), BorderLayout.CENTER);
		//frame components
		maintenance.setLayout(new GridLayout(1, 2, 5, 5));
		maintenance.add(form);
		maintenance.add(cluster);
		
		//TRANSACTION FORM
		
		/*transaction.setLayout(new GridLayout(1, 2, 5, 5));
		kmeans_panel.setLayout(new BorderLayout());
		kmeans_panel.add(new JScrollPane(clusterTable), BorderLayout.CENTER);
		kmeans_panel.add(clusterButton, BorderLayout.SOUTH);
		kmeans_panel.add(progressBar, BorderLayout.NORTH);
		
		transaction.add(factor_panel);
		transaction.add(kmeans_panel);*/
		
		//FACTOR FORM
		
		factor_form.add(f_assetCodeFieldLabel);
		factor_form.add(f_assetCodeField);
		factor_form.add(f_assetNameFieldLabel);
		factor_form.add(f_assetNameField);
		factor_form.add(ff_categoryLabel);
		factor_form.add(ff_category);
		factor_form.add(ff_subcategoryLabel);
		factor_form.add(ff_subcategory);
		factor_form.add(f_acqDateFieldLabel);
		factor_form.add(f_date);
		factor_form.add(f_lifeFieldLabel);
		factor_form.add(f_lifeSpinner);
		factor_form.add(f_acqValueFieldLabel);
		factor_form.add(f_acqValueField);
		factor_form.add(f_salvageValueFieldLabel);
		factor_form.add(f_salvageValueField);
		factor_form.add(ff_usageLabel);
		factor_form.add(ff_usageFactor);
		factor_form.add(ff_ageLabel);
		factor_form.add(ff_ageFactor);
		//layout2 on Form4
		layout2.putConstraint(SpringLayout.WEST, f_assetCodeFieldLabel, 10, SpringLayout.WEST, factor_form);
		layout2.putConstraint(SpringLayout.NORTH, f_assetCodeFieldLabel, 10, SpringLayout.NORTH, factor_form);
		layout2.putConstraint(SpringLayout.WEST, f_assetCodeField, 35, SpringLayout.EAST, f_assetCodeFieldLabel);
		layout2.putConstraint(SpringLayout.NORTH, f_assetCodeField, 10, SpringLayout.NORTH, factor_form);
		
		layout2.putConstraint(SpringLayout.WEST, f_assetNameFieldLabel, 10, SpringLayout.WEST, factor_form);
		layout2.putConstraint(SpringLayout.NORTH, f_assetNameFieldLabel, 25, SpringLayout.SOUTH, f_assetCodeFieldLabel);
		layout2.putConstraint(SpringLayout.WEST, f_assetNameField, 100, SpringLayout.EAST, f_assetNameFieldLabel);
		layout2.putConstraint(SpringLayout.NORTH, f_assetNameField, 20, SpringLayout.SOUTH, f_assetCodeField);
		
		layout2.putConstraint(SpringLayout.WEST, ff_categoryLabel, 10, SpringLayout.WEST, factor_form);
		layout2.putConstraint(SpringLayout.NORTH, ff_categoryLabel, 25, SpringLayout.SOUTH, f_assetNameFieldLabel);
		layout2.putConstraint(SpringLayout.WEST, ff_category, 93, SpringLayout.EAST, f_categoryLabel);
		layout2.putConstraint(SpringLayout.NORTH, ff_category, 20, SpringLayout.SOUTH, f_assetNameField);
		
		layout2.putConstraint(SpringLayout.WEST, ff_subcategoryLabel, 10, SpringLayout.WEST, factor_form);
		layout2.putConstraint(SpringLayout.NORTH, ff_subcategoryLabel, 25, SpringLayout.SOUTH, ff_categoryLabel);
		layout2.putConstraint(SpringLayout.WEST, ff_subcategory, 130, SpringLayout.EAST, ff_subcategoryLabel);
		layout2.putConstraint(SpringLayout.NORTH, ff_subcategory, 20, SpringLayout.SOUTH, ff_category);
		
		layout2.putConstraint(SpringLayout.WEST, f_acqDateFieldLabel, 10, SpringLayout.WEST, factor_form);
		layout2.putConstraint(SpringLayout.NORTH, f_acqDateFieldLabel, 25, SpringLayout.SOUTH, ff_subcategoryLabel);
		layout2.putConstraint(SpringLayout.WEST, f_date, 110, SpringLayout.EAST, f_acqDateFieldLabel);
		layout2.putConstraint(SpringLayout.NORTH, f_date, 20, SpringLayout.SOUTH, ff_subcategory);
		
		layout2.putConstraint(SpringLayout.WEST, f_lifeFieldLabel, 10, SpringLayout.WEST, factor_form);
		layout2.putConstraint(SpringLayout.NORTH, f_lifeFieldLabel, 25, SpringLayout.SOUTH, f_acqDateFieldLabel);
		layout2.putConstraint(SpringLayout.WEST, f_lifeSpinner, 132, SpringLayout.EAST, f_lifeFieldLabel);
		layout2.putConstraint(SpringLayout.NORTH, f_lifeSpinner, 20, SpringLayout.SOUTH, f_date);
		
		layout2.putConstraint(SpringLayout.WEST, f_acqValueFieldLabel, 10, SpringLayout.WEST, factor_form);
		layout2.putConstraint(SpringLayout.NORTH, f_acqValueFieldLabel, 25, SpringLayout.SOUTH, f_lifeFieldLabel);
		layout2.putConstraint(SpringLayout.WEST, f_acqValueField, 100, SpringLayout.EAST, f_acqValueFieldLabel);
		layout2.putConstraint(SpringLayout.NORTH, f_acqValueField, 20, SpringLayout.SOUTH, f_lifeSpinner);
		
		layout2.putConstraint(SpringLayout.WEST, f_salvageValueFieldLabel, 10, SpringLayout.WEST, factor_form);
		layout2.putConstraint(SpringLayout.NORTH, f_salvageValueFieldLabel, 25, SpringLayout.SOUTH, f_acqValueFieldLabel);
		layout2.putConstraint(SpringLayout.WEST, f_salvageValueField, 117, SpringLayout.EAST, f_salvageValueFieldLabel);
		layout2.putConstraint(SpringLayout.NORTH, f_salvageValueField, 20, SpringLayout.SOUTH, f_acqValueField);
		
		layout2.putConstraint(SpringLayout.WEST, ff_usageLabel, 10, SpringLayout.WEST, factor_form);
		layout2.putConstraint(SpringLayout.NORTH, ff_usageLabel, 25, SpringLayout.SOUTH, f_salvageValueFieldLabel);
		layout2.putConstraint(SpringLayout.WEST, ff_usageFactor, 125, SpringLayout.EAST, ff_usageLabel);
		layout2.putConstraint(SpringLayout.NORTH, ff_usageFactor, 20, SpringLayout.SOUTH, f_salvageValueField);
		
		layout2.putConstraint(SpringLayout.WEST, ff_ageLabel, 10, SpringLayout.WEST, factor_form);
		layout2.putConstraint(SpringLayout.NORTH, ff_ageLabel, 25, SpringLayout.SOUTH, ff_usageLabel);
		layout2.putConstraint(SpringLayout.WEST, ff_ageFactor, 140, SpringLayout.EAST, ff_ageLabel);
		layout2.putConstraint(SpringLayout.NORTH, ff_ageFactor, 20, SpringLayout.SOUTH, ff_usageFactor);
		
			
		
		
		kmeans_panel.add(subLabel);
		kmeans_panel.add(k_subCategoryField);
		kmeans_panel.add(algorithmLabel);
		kmeans_panel.add(algorithm);
		kmeans_panel.add(clusterButton);
		
		layout3.putConstraint(SpringLayout.WEST, subLabel, 10, SpringLayout.WEST, kmeans_panel);
		layout3.putConstraint(SpringLayout.NORTH, subLabel, 25, SpringLayout.NORTH, kmeans_panel);
		layout3.putConstraint(SpringLayout.NORTH, k_subCategoryField, 20, SpringLayout.NORTH, kmeans_panel);
		layout3.putConstraint(SpringLayout.WEST, k_subCategoryField, 20, SpringLayout.EAST, subLabel);
		
		layout3.putConstraint(SpringLayout.WEST, algorithmLabel, 10, SpringLayout.WEST, kmeans_panel);
		layout3.putConstraint(SpringLayout.NORTH, algorithmLabel, 25, SpringLayout.SOUTH, subLabel);
		layout3.putConstraint(SpringLayout.WEST, algorithm, 35, SpringLayout.EAST, algorithmLabel);
		layout3.putConstraint(SpringLayout.NORTH, algorithm, 20, SpringLayout.SOUTH, subLabel);
		
		layout3.putConstraint(SpringLayout.WEST, clusterButton, 0, SpringLayout.WEST, kmeans_panel);
		layout3.putConstraint(SpringLayout.NORTH, clusterButton, 25, SpringLayout.SOUTH, algorithmLabel);
		
		cluster_form.add(factor_form2);
		cluster_form.add(kmeans_panel);
		
		factor_panel.add(factor_form, BorderLayout.CENTER);
		factor_button.add(fb_Save);
		factor_panel.add(factor_button, BorderLayout.SOUTH);
		factor_form2.add(new JScrollPane(factorTB), BorderLayout.CENTER);	
		
		factor_main.add(factor_panel);
		factor_main.add(cluster_form);
		
		//QUERY 
		levelNorthPanel.add(levelLabel);
		levelNorthPanel.add(cFilterLabel);
		levelNorthPanel.add(Filter);
		levelNorthPanel.add(sbFilterLabel);
		levelNorthPanel.add(sbFilter);
		levelNorthPanel.add(filterButton);
		levelCenterPanel.add(new JScrollPane(levelTB), BorderLayout.CENTER);
		levelMainPanel.add(levelNorthPanel, BorderLayout.NORTH);
		levelMainPanel.add(levelCenterPanel, BorderLayout.CENTER);
		
		netCenterPanel.add(new JScrollPane(netTB), BorderLayout.CENTER);
		netMainPanel.add(netLabel, BorderLayout.NORTH);
		netMainPanel.add(netCenterPanel, BorderLayout.CENTER);
		
		salvageCenterPanel.add(new JScrollPane(salvageTB), BorderLayout.CENTER);
		salvageMainPanel.add(salvageLabel, BorderLayout.NORTH);
		salvageMainPanel.add(salvageCenterPanel, BorderLayout.CENTER);
		
		//indiv result
		//kmeans panel
		iKNorth.add(kMeanTitle);
		iKCenter.add(kMeanAsset);
		iKCenter.add(kMeanLevel);
		iKCenter.add(kMeanIteration);
		iKCenter.add(kMeanBatch);
		iKMain.add(iKNorth, BorderLayout.NORTH);
		iKMain.add(iKCenter, BorderLayout.CENTER);
		
		iENorth.add(eKMeanTitle);
		iECenter.add(eKMeanAsset);
		iECenter.add(eKMeanLevel);
		iECenter.add(eKMeanIteration);
		iECenter.add(eKMeanBatch);
		iEMain.add(iENorth, BorderLayout.NORTH);
		iEMain.add(iECenter, BorderLayout.CENTER);
		
		indivCenter.add(iKMain);
		indivCenter.add(iEMain);
		
		indivNorth.add(listAsssetLabel);
		indivNorth.add(listAsset);
		indivNorth.add(indivButton);
		
		indivMain.add(indivNorth, BorderLayout.NORTH);
		indivMain.add(indivCenter, BorderLayout.CENTER);
		
		QueryForm.addTab("Individual Result", indivMain);
		QueryForm.addTab("Level of Maintenance", levelMainPanel);
		QueryForm.addTab("Net Value", netMainPanel);
		QueryForm.addTab("Fixed Asset that Reached Salvage Value", salvageMainPanel);
		
		//dashboard
		
		//kConsistency
		kConsistency.add(kConLabel, BorderLayout.NORTH);
		kConsistency.add(kConValue, BorderLayout.CENTER);
		
		//eConsistency
		eConsistency.add(eConLabel, BorderLayout.NORTH);
		eConsistency.add(eConValue, BorderLayout.CENTER);
		
		//north
		dashConsPanel.add(kConsistency);
		dashConsPanel.add(eConsistency);
		dashFilterPanel.add(dashFilterLabel);
		dashFilterPanel.add(dashFilterCB);
		dashFilterPanel.add(dashFilterButton);
		dashboardNorth.add(dashFilterPanel);
		dashboardNorth.add(dashConsPanel);
		
		//kAveSpeed
		kAveSpeed.add(kAveSpeedLabel, BorderLayout.NORTH);
		kAveSpeed.add(kAveSpeedValue, BorderLayout.CENTER);
		
		//eAveSpeed
		eAveSpeed.add(eAveSpeedLabel, BorderLayout.NORTH);
		eAveSpeed.add(eAveSpeedValue, BorderLayout.CENTER);
		
		//AveIter
		kAveIter.add(kAveIterLabel, BorderLayout.NORTH);
		kAveIter.add(kAveIterValue, BorderLayout.CENTER);
				
		//eAveIter
		eAveIter.add(eAveIterLabel, BorderLayout.NORTH);
		eAveIter.add(eAveIterValue, BorderLayout.CENTER);
		
		
		//south
		dashBoardSouth.add(kAveSpeed);
		dashBoardSouth.add(eAveSpeed);
		dashBoardSouth.add(kAveIter);
		dashBoardSouth.add(eAveIter);
		
		dashboard.add(dashboardNorth, BorderLayout.NORTH);
		dashboard.add(dashBoardCenter, BorderLayout.CENTER);
		dashboard.add(dashBoardSouth, BorderLayout.SOUTH);
	
		system.addTab("Fixed Asset Maintenance", maintenance);
		system.addTab("Clustering", factor_main);
		system.addTab("Utility", utility);
		system.addTab("Queries", QueryForm);
		system.addTab("Dashboard", dashboard);
		
		assetView.add(system);
		
		//frame
		assetView.getContentPane().setBackground(Color.white);
		assetView.setSize(1200, 700);
		assetView.setVisible(true);
		assetView.setLocationRelativeTo(null);
	}
	
	public void initiate(){
		assetView = new JFrame("Fixed Asset Monitoring System");
		form = new JPanel(new BorderLayout());
		cluster = new JPanel(new BorderLayout());
		assetView.setBackground(Color.WHITE);
		form.setBackground(Color.WHITE);
		cluster.setBackground(Color.WHITE);
		
		//form components
		centerForm = new JPanel();
		layout = new SpringLayout();
		centerForm.setLayout(layout);
		centerForm.setBackground(Color.WHITE);
		
		formName = new JLabel("Fixed Assets Form");
		formName.setForeground(new Color(123, 0, 0));
		assetCodeFieldLabel = new JLabel("Fixed Asset Property Number:");
		assetCodeFieldLabel.setForeground(new Color(123, 0, 0));
		assetCodeField = new JTextField(20);
		assetNameFieldLabel = new JLabel("Fixed Asset Name:");
		assetNameFieldLabel.setForeground(new Color(123, 0, 0));
		assetNameField = new JTextField(20);
		acqDateFieldLabel = new JLabel("Acquisition Date:");
		acqDateFieldLabel.setForeground(new Color(123, 0, 0));
		modelDate = new UtilDateModel();
		p = new Properties();
		p.put("text.today", "Today");
		p.put("text.month", "Month");
		p.put("text.year", "Year");
		datePanel = new JDatePanelImpl(modelDate, p);
		datePicker = new JDatePickerImpl(datePanel, new DateLabelFormatter());
		lifeFieldLabel = new JLabel("Service Life: ");
		lifeFieldLabel.setForeground(new Color(123, 0, 0));
		numberSpin = new SpinnerNumberModel(1, //initial number
				1, //min
				100, //max
				1 //step
				);
		lifeSpinner = new JSpinner(numberSpin);
		acqValueFieldLabel = new JLabel("Acquisition Value: ");
		acqValueFieldLabel.setForeground(new Color(123, 0, 0));
		acqValueField = new JFormattedTextField(amountFormat);
		acqValueField.setValue(new Double(acq));
		acqValueField.setColumns(10);
		acqValueField.addPropertyChangeListener("value", this);
		salvageValueFieldLabel = new JLabel("Salvage Value: ");
		salvageValueFieldLabel.setForeground(new Color(123, 0, 0));
		salvageValueField = new JFormattedTextField(amountFormat);
		salvageValueField.setValue(new Double(salvage));
		salvageValueField.setColumns(10);
		salvageValueField.addPropertyChangeListener("value", this);
		salvageValueField.setEditable(false);
		
		f_categoryField = new JComboBox<String>();
		f_categoryLabel = new JLabel("Fixed Asset Category:");
		f_categoryLabel.setForeground(new Color(123, 0, 0));
		f_subCategoryLabel = new JLabel("Fixed Asset sub-Category");
		f_subCategoryLabel.setForeground(new Color(123, 0, 0));
		f_subCategory = new JComboBox<String>();
	
		//cluster components
		clusterName = new JLabel("Asset Cluster:");
		clusterName.setForeground(new Color(123, 0, 0));
		columnNames = new String[6];
		columnNames[0] = "Property Number";
		columnNames[1] = "Name";
		columnNames[2] = "Acquisition Date";
		columnNames[3] = "Acquisition Value";
		columnNames[4] = "Salvage Value";
		columnNames[5] = "Service Life";
		model = new DefaultTableModel(20, columnNames.length);
		model.setColumnIdentifiers(columnNames);
		dataTable = new JTable(model);
		dataTable.setDefaultEditor(Object.class, null);
		
		//Button components
		buttonPanel = new JPanel();
		buttonPanel.setBackground(Color.WHITE);
		addButton = new JButton("ADD");
		addButton.setBackground(Color.DARK_GRAY);
		addButton.setForeground(new Color(128, 0, 0));
		addButton.setOpaque(false);
		addButton.setBorderPainted(false);
		
		clearButton = new JButton("CLEAR");
		clearButton.setBackground(Color.DARK_GRAY);
		clearButton.setForeground(new Color(128, 0, 0));
		clearButton.setOpaque(false);
		clearButton.setBorderPainted(false);
		
		deleteButton = new JButton("DISPOSE");
		deleteButton.setBackground(Color.DARK_GRAY);
		deleteButton.setForeground(new Color(128, 0, 0));
		deleteButton.setOpaque(false);
		deleteButton.setBorderPainted(false);
		
		searchButton = new JButton("SEARCH");
		searchButton.setBackground(Color.DARK_GRAY);
		searchButton.setForeground(new Color(128, 0, 0));
		searchButton.setOpaque(false);
		searchButton.setBorderPainted(false);
		
		editButton = new JButton("EDIT");
		editButton.setBackground(Color.DARK_GRAY);
		editButton.setForeground(new Color(128, 0, 0));
		editButton.setOpaque(false);
		editButton.setBorderPainted(false);
		
		updateButton = new JButton("UPDATE");
		updateButton.setEnabled(false);
		updateButton.setBackground(Color.DARK_GRAY);
		updateButton.setForeground(new Color(128, 0, 0));
		updateButton.setOpaque(false);
		updateButton.setBorderPainted(false);
		
		
		maintenance = new JPanel();
		maintenance.setBackground(Color.WHITE);
		system = new JTabbedPane();
		system.setBackground(Color.WHITE);
		system.setForeground(Color.DARK_GRAY);
		
		//TRANSACTION FORM
		transaction = new JPanel();
		transaction.setBackground(Color.WHITE);
		
		//cluster components
		names = new String[9];
		names[0] = "Property Number";
		names[1] = "Name";
		names[2] = "Category";
		names[3] = "Sub-Category";
		names[4] = "Age Factor";
		names[5] = "Usage Factor";
		names[6] = "Cluster EMeans";
		names[7] = "Cluster KMeans";
		names[8] = "Cluster Date";
		clusterModel = new DefaultTableModel(0, names.length);
		clusterModel.setColumnIdentifiers(names);
		clusterTable = new JTable(clusterModel);
		clusterTable.setDefaultEditor(Object.class, null);
		
		clusterButton = new JButton("CLUSTER");
		clusterButton.setBackground(Color.DARK_GRAY);
		clusterButton.setForeground(new Color(128, 0, 0));
		clusterButton.setOpaque(false);
		clusterButton.setBorderPainted(false);
		
		progressBar = new JProgressBar(0, 100);
		progressBar.setValue(0);
		progressBar.setStringPainted(true);
		
		
		//Utility Form 
		utility = new JPanel(new GridLayout(1, 2, 0, 0));
		utilityNorth = new JPanel();
		utilitySouth = new JPanel();
		utility.setBackground(Color.white);
		utilityNorth.setBackground(Color.white);
		utilitySouth.setBackground(Color.white);
		
		category_panel = new JPanel(new BorderLayout());
		subcategory_panel = new JPanel(new BorderLayout());
		button_SC_panel = new JPanel();
		subcategory_panel_north = new JPanel();
		
		category_panel.setBackground(Color.white);
		subcategory_panel.setBackground(Color.white);
		button_SC_panel.setBackground(Color.white);
		subcategory_panel_north.setBackground(Color.white);
		
		//Transaction Panel
		factor_panel = new JPanel();
		kmeans_panel =  new JPanel();
		
		categoryField = new JTextField(10);
		categoryLabel = new JLabel("Category:");
		categoryLabel.setForeground(new Color(123, 0, 0));
		subCategoryLabel = new JLabel("Sub-Category");
		subCategoryLabel.setForeground(new Color(123, 0, 0));
		subCategory = new JTextField(10);
		c_name = new String[1];
		c_name[0] = "Category";
		categoryModel = new DefaultTableModel(0, c_name.length);
		categoryModel.setColumnIdentifiers(c_name);
		categoryTB = new JTable(categoryModel);
		categoryTB.setDefaultEditor(Object.class, null);
		
		sc_name = new String[2];
		sc_name[0] = "Category";
		sc_name[1] = "Sub Category";
		subcategoryModel = new DefaultTableModel(0, sc_name.length);
		subcategoryModel.setColumnIdentifiers(sc_name);
		subcategoryTB = new JTable(subcategoryModel);
		subcategoryTB.setDefaultEditor(Object.class, null);
		
		c_Save = new JButton("SAVE");
		c_Save.setBackground(Color.DARK_GRAY);
		c_Save.setForeground(new Color(128, 0, 0));
		c_Save.setOpaque(false);
		c_Save.setBorderPainted(false);
		
		c_Edit = new JButton("EDIT");
		c_Edit.setBackground(Color.DARK_GRAY);
		c_Edit.setForeground(new Color(128, 0, 0));
		c_Edit.setOpaque(false);
		c_Edit.setBorderPainted(false);
		
		c_Update = new JButton("UPDATE");
		c_Update.setEnabled(false);
		c_Update.setBackground(Color.DARK_GRAY);
		c_Update.setForeground(new Color(128, 0, 0));
		c_Update.setOpaque(false);
		c_Update.setBorderPainted(false);
		
		c_Delete = new JButton("DELETE");
		c_Delete.setBackground(Color.DARK_GRAY);
		c_Delete.setForeground(new Color(128, 0, 0));
		c_Delete.setOpaque(false);
		
		s_Save = new JButton("SAVE");
		s_Save.setBackground(Color.DARK_GRAY);
		s_Save.setForeground(new Color(128, 0, 0));
		s_Save.setOpaque(false);
		s_Save.setBorderPainted(false);
		
		s_Edit = new JButton("EDIT");
		s_Edit.setBackground(Color.DARK_GRAY);
		s_Edit.setForeground(new Color(128, 0, 0));
		s_Edit.setOpaque(false);
		s_Edit.setBorderPainted(false);
		
		s_Update = new JButton("UPDATE");
		s_Update.setEnabled(false);
		s_Update.setBackground(Color.DARK_GRAY);
		s_Update.setForeground(new Color(128, 0, 0));
		s_Update.setOpaque(false);
		s_Update.setBorderPainted(false);
		
		s_Delete = new JButton("DELETE");
		s_Delete.setBackground(Color.DARK_GRAY);
		s_Delete.setForeground(new Color(128, 0, 0));
		s_Delete.setOpaque(false);
		
		s_Delete.setBorderPainted(false);
		
		CB_category = new JComboBox<String>();
		cb_categoryLabel = new JLabel("Category: ");
		
		//factor panel
		f_name = new String[4];
		f_name[0] = "Fixed Asset ID";
		f_name[1] = "Name";
		f_name[2] = "Usage Factor";
		f_name[3] = "Age Factor";
		factorModel = new DefaultTableModel(0, f_name.length);
		factorModel.setColumnIdentifiers(f_name);
		factorTB = new JTable(factorModel);
		factorTB.setDefaultEditor(Object.class, null);
		
		
		factor_panel = new JPanel(new BorderLayout());
		factor_button = new JPanel();
		factor_main = new JPanel(new GridLayout(1, 2, 0, 0));
		
		fb_Save = new JButton("SAVE");
		fb_Save.setBackground(Color.DARK_GRAY);
		fb_Save.setForeground(new Color(128, 0, 0));
		fb_Save.setOpaque(false);
		fb_Save.setBorderPainted(false);
		
		
		//factor 
		f_formName = new JLabel("Age and Usage Factor Form");
		f_formName.setForeground(new Color(123, 0, 0));
		f_assetCodeFieldLabel = new JLabel("Fixed Asset Property Number:");
		f_assetCodeFieldLabel.setForeground(new Color(123, 0, 0));
		f_assetCodeField = new JComboBox<String>();
		f_assetNameFieldLabel = new JLabel("Fixed Asset Name:");
		f_assetNameFieldLabel.setForeground(new Color(123, 0, 0));
		f_assetNameField = new JTextField(20);
		f_acqDateFieldLabel = new JLabel("Acquisition Date:");
		f_acqDateFieldLabel.setForeground(new Color(123, 0, 0));
		f_date = new JTextField(20);
		f_lifeFieldLabel = new JLabel("Service Life: ");
		f_lifeFieldLabel.setForeground(new Color(123, 0, 0));
		f_numberSpin = new SpinnerNumberModel(1, //initial number
				1, //min
				100, //max
				1 //step
				);
		f_lifeSpinner = new JSpinner(f_numberSpin);
		f_acqValueFieldLabel = new JLabel("Acquisition Value: ");
		f_acqValueFieldLabel.setForeground(new Color(123, 0, 0));
		f_acqValueField = new JTextField(20);
		f_salvageValueFieldLabel = new JLabel("Salvage Value: ");
		f_salvageValueFieldLabel.setForeground(new Color(123, 0, 0));
		f_salvageValueField = new JTextField(20);

		
		f_assetNameField.setEditable(false);
		f_date.setEditable(false);
		f_lifeSpinner.setEnabled(false);
		f_acqValueField.setEditable(false);
		f_salvageValueField.setEditable(false);
		
		factor_form = new JPanel();
		layout2 = new SpringLayout();
		factor_form.setLayout(layout2);
		factor_form.setBackground(Color.WHITE);
		factor_form2 = new JPanel(new BorderLayout());
		factor_form2.setBackground(Color.WHITE);
		factor_button = new JPanel();
		factor_button.setBackground(Color.WHITE);
		
		ff_categoryLabel = new JLabel("Category:");
		ff_categoryLabel.setForeground(new Color(123, 0, 0));
		ff_category = new JTextField(20);
		ff_subcategoryLabel = new JLabel("Subcategory:");
		ff_subcategoryLabel.setForeground(new Color(123, 0, 0));
		ff_subcategory = new JTextField(20);
		ff_category.setEditable(false);
		ff_subcategory.setEditable(false);
		
		ff_usageLabel = new JLabel("Usage Factor:");
		ff_usageLabel.setForeground(new Color(123, 0, 0));
		ff_usageFactor = new JTextField(20);
		ff_ageLabel = new JLabel("Age Factor:");
		ff_ageLabel.setForeground(new Color(123, 0, 0));
		ff_ageFactor = new JTextField(20);
		ff_ageFactor.setEditable(false);
		
		//kmeans panel
		
		cluster_form = new JPanel(new GridLayout(2, 1, 0, 0));
		kmeans_panel = new JPanel();
		layout3 = new SpringLayout();
		kmeans_panel.setLayout(layout3);
		kmeans_panel.setBackground(Color.WHITE);
		cluster_form.setBackground(Color.WHITE);
		
		
		algorithm = new JComboBox<String>();
		k_subCategoryField = new JComboBox<String>();
		subLabel = new JLabel("Category:");
		subLabel.setForeground(new Color(123, 0, 0));
		algorithmLabel = new JLabel("Algorithm:");
		algorithmLabel.setForeground(new Color(123, 0, 0));
		
		levelName = new String[8];
		levelName[0] = "Fixed Asset ID";
		levelName[1] = "Name";
		levelName[2] = "Category";
		levelName[3] = "Subcategory";
		levelName[4] = "Usage Factor";
		levelName[5] = "Age Factor";
		levelName[6] = "Level of Maintenance in K-MEANS";
		levelName[7] = "Level of Maintenance in ENHANCED";
		levelModel = new DefaultTableModel(0, levelName.length);
		levelModel.setColumnIdentifiers(levelName);
		levelTB = new JTable(levelModel);
		levelTB.setDefaultEditor(Object.class, null);
		
		cFilterLabel = new JLabel("Category:");
		Filter = new JComboBox<String>();
		filterButton = new JButton("FILTER");
		
		sbFilterLabel = new JLabel("Subcategory:");
		sbFilter = new JComboBox<String>();
		
		levelNorthPanel = new JPanel();
		
		netName = new String[9];
		netName[0] = "Fixed Asset ID";
		netName[1] = "Name";
		netName[2] = "Category";
		netName[3] = "SubCategory";
		netName[4] = "acquisition date";
		netName[5] = "acquisition value";
		netName[6] = "salvage value";
		netName[7] = "Monthly Depreciation";
		netName[8] = "Net Value";
		netModel = new DefaultTableModel(0, netName.length);
		netModel.setColumnIdentifiers(netName);
		netTB = new JTable(netModel);
		netTB.setDefaultEditor(Object.class, null);
		
		salvageName = new String[9];
		salvageName[0] = "Fixed Asset ID";
		salvageName[1] = "Name";
		salvageName[2] = "Category";
		salvageName[3] = "SubCategory";
		salvageName[4] = "acquisition date";
		salvageName[5] = "acquisition value";
		salvageName[6] = "salvage value";
		salvageName[7] = "Monthly Depreciation";
 		salvageName[8] = "Net Value";
		salvageModel = new DefaultTableModel(0, salvageName.length);
		salvageModel.setColumnIdentifiers(salvageName);
		salvageTB = new JTable(salvageModel);
		salvageTB.setDefaultEditor(Object.class, null);
		
		levelLabel = new JLabel("Fixed Asset Level of Maintenance");
		netLabel =  new JLabel("Fixed Asset Net Value");
		salvageLabel = new JLabel("Fixed Asset that reached Salvage Value");
		
		
		levelCenterPanel = new JPanel(new BorderLayout());
		levelMainPanel =  new JPanel(new BorderLayout());
		levelCenterPanel.setBackground(Color.WHITE);
		levelMainPanel.setBackground(Color.WHITE);
		
		netCenterPanel = new JPanel(new BorderLayout());
		netMainPanel =  new JPanel(new BorderLayout());
		netCenterPanel.setBackground(Color.WHITE);
		netMainPanel.setBackground(Color.WHITE);
		
		salvageCenterPanel = new JPanel(new BorderLayout());
		salvageMainPanel =  new JPanel(new BorderLayout());
		salvageCenterPanel.setBackground(Color.WHITE);
		salvageMainPanel.setBackground(Color.WHITE);
		
		QueryForm = new JTabbedPane();
		QueryForm.setBackground(Color.WHITE);
		
		
		//dashboard
		dashboard = new JPanel(new BorderLayout());
		dashboard.setBackground(Color.WHITE);
		dashboardNorth = new JPanel(new GridLayout(2, 1, 0, 0));
		dashboardNorth.setBackground(Color.WHITE);
		dashBoardCenter = new JPanel(new BorderLayout());
		dashBoardCenter.setBackground(Color.WHITE);
		dashBoardSouth = new JPanel(new GridLayout(1, 4, 10, 10));
		dashBoardSouth.setBackground(Color.WHITE);
		kConsistency = new JPanel(new BorderLayout());
		kConsistency.setBackground(Color.PINK);
		eConsistency = new JPanel(new BorderLayout());
		eConsistency.setBackground(Color.PINK);
		kAveSpeed = new JPanel(new BorderLayout());
		kAveSpeed.setBackground(Color.LIGHT_GRAY);
		eAveSpeed = new JPanel(new BorderLayout());
		eAveSpeed.setBackground(Color.LIGHT_GRAY);
		kAveIter = new JPanel(new BorderLayout());
		kAveIter.setBackground(Color.ORANGE);
		eAveIter = new JPanel(new BorderLayout());
		eAveIter.setBackground(Color.ORANGE);
		
		kConLabel =  new JLabel("K-Means Consistency (%)");
		eConLabel = new JLabel("Enhanced K-Means Consistency (%)");
		kAveSpeedLabel = new JLabel("K-Means Average Speed (milli)");
		eAveSpeedLabel = new JLabel("Enhanced K-Means Average Speed (milli)");
		kAveIterLabel = new JLabel("K-Means Average Number of Iteration");
		eAveIterLabel = new JLabel("Enhanced K-Means Average Number of Iteration");
		
		kConValue =  new JLabel("0");
		kConValue.setFont(new Font("Serif", Font.BOLD, 30));
		eConValue = new JLabel("0");
		eConValue.setFont(new Font("Serif", Font.BOLD, 30));
		kAveSpeedValue = new JLabel("0");
		kAveSpeedValue.setFont(new Font("Serif", Font.BOLD, 30));
		eAveSpeedValue = new JLabel("0");
		eAveSpeedValue.setFont(new Font("Serif", Font.BOLD, 30));
		kAveIterValue = new JLabel("0");
		kAveIterValue.setFont(new Font("Serif", Font.BOLD, 30));
		eAveIterValue = new JLabel("0");
		eAveIterValue.setFont(new Font("Serif", Font.BOLD, 30));
		
		dashFilterLabel = new JLabel("Category: ");

		dashFilterCB =  new JComboBox<String>();
		dashFilterButton = new JButton("Enter");
		
		dashNorthPanel = new JPanel(new GridLayout(2, 1, 0, 0));
		dashNorthPanel.setBackground(Color.WHITE);
		dashFilterPanel = new JPanel();
		dashFilterPanel.setBackground(Color.WHITE);
		dashConsPanel =  new JPanel(new GridLayout(1, 2, 10, 10));
		dashConsPanel.setBackground(Color.WHITE);
		
		//indiv result
		indivMain = new JPanel(new BorderLayout());
		indivMain.setBackground(Color.WHITE);
		indivNorth = new JPanel();
		indivNorth.setBackground(Color.WHITE);
		indivCenter = new JPanel(new GridLayout(1,2,5,5));
		indivCenter.setBackground(Color.WHITE);
		iKMain = new JPanel(new BorderLayout());
		iKMain.setBackground(Color.WHITE);
		iKMain.setBorder(BorderFactory.createMatteBorder(
                1, 5, 1, 1, Color.ORANGE));
		iKNorth = new JPanel();
		iKNorth.setBackground(Color.WHITE);
		iKCenter = new JPanel(new GridLayout(4,1, 10, 10));
		iKCenter.setBackground(Color.WHITE);
		iEMain = new JPanel(new BorderLayout());
		iEMain.setBackground(Color.WHITE);
		iEMain.setBorder(BorderFactory.createMatteBorder(
                                    1, 5, 1, 1, Color.RED));
		iENorth = new JPanel();
		iENorth.setBackground(Color.WHITE);
		iECenter = new JPanel(new GridLayout(4,1,10,10));
		iECenter.setBackground(Color.WHITE);
		
		listAsset = new JComboBox<String>();
		listAsssetLabel =  new JLabel("Individual Result of Algorithm");
		indivButton = new JButton("Enter");
		
		kMeanTitle =  new JLabel("Result of Clustering using K-Means Algorithm");
		kMeanTitle.setFont(new Font("Serif", Font.BOLD, 20));
		kMeanAsset = new JLabel("Fixed Asset ID: Fixed Asset Name");
		kMeanAsset.setFont(new Font("Serif", Font.BOLD, 18));
		kMeanAsset.setHorizontalAlignment(JLabel.CENTER);
		kMeanLevel = new JLabel("Level of Maintenance: Unclustered");
		kMeanLevel.setFont(new Font("Serif", Font.BOLD, 18));
		kMeanLevel.setHorizontalAlignment(JLabel.CENTER);
		kMeanIteration = new JLabel("Number of Iterations: 0");
		kMeanIteration.setHorizontalAlignment(JLabel.CENTER);
		kMeanIteration.setFont(new Font("Serif", Font.BOLD, 18));
		kMeanBatch =  new JLabel("Clustering Batch: ");
		kMeanBatch.setHorizontalAlignment(JLabel.CENTER);
		kMeanBatch.setFont(new Font("Serif", Font.BOLD, 18));
		
		eKMeanTitle =  new JLabel("Result of Clustering using Enhanced K-Means Algorithm");
		eKMeanTitle.setFont(new Font("Serif", Font.BOLD, 20));
		eKMeanAsset = new JLabel("Fixed Asset ID: Fixed Asset Name");
		eKMeanAsset.setFont(new Font("Serif", Font.BOLD, 18));
		eKMeanAsset.setHorizontalAlignment(JLabel.CENTER);
		eKMeanLevel = new JLabel("Level of Maintenance: Unclustered");
		eKMeanLevel.setFont(new Font("Serif", Font.BOLD, 18));
		eKMeanLevel.setHorizontalAlignment(JLabel.CENTER);
		eKMeanIteration = new JLabel("Number of Iterations: 0");
		eKMeanIteration.setHorizontalAlignment(JLabel.CENTER);
		eKMeanIteration.setFont(new Font("Serif", Font.BOLD, 18));
		eKMeanBatch =  new JLabel("Clustering Batch: ");
		eKMeanBatch.setHorizontalAlignment(JLabel.CENTER);
		eKMeanBatch.setFont(new Font("Serif", Font.BOLD, 18));
		
		
		
	}
	
	
	public static void create(){
		
		@SuppressWarnings("unused")
		ASSETVIEW frame = new ASSETVIEW();
		model.setRowCount(0);
		DBEKMEANS.LoadDriver();
		DBEKMEANS.TestConnection();
		
		TBLASSET.refresh();
		
		try{
			
			DBEKMEANS.TestConnection();
			
			String factor =  "SELECT tbl_asset.asset_code, fixedAssetName, usage_factor, age_factor FROM tbl_asset left join tbl_factor on tbl_asset.asset_code = tbl_factor.asset_code WHERE tbl_asset.disposed IS NULL";
			PreparedStatement ps = DBEKMEANS.conn.prepareStatement(factor);
				
			ResultSet rset = ps.executeQuery();
				
			while(rset.next()){
				String ac = rset.getString("asset_code");
				String an = rset.getString("fixedAssetName");
				double uf = rset.getDouble("usage_factor");
				double af = rset.getDouble("age_factor");
				
				DecimalFormat df2 = new DecimalFormat("0.000"); 
					
				Object[] row2 = {ac, an, df2.format(uf), df2.format(af)};
				ASSETVIEW.factorModel.addRow(row2);
			}
				
			rset.close();
			ps.close();
			DBEKMEANS.conn.close();
			
			
			
			//removed transaction database select
			/*String sql1 = "SELECT * FROM  f_cluster right Join d_asset on d_asset.asset_code = f_cluster.asset_code join d_clustering on f_cluster.cluster_id = d_clustering.cluster_id join r_category on r_category.category_id = d_asset.fasset_category WHERE disposed IS NULL";
			PreparedStatement select1 = DBEKMEANS.conn.prepareStatement(sql1);
			
			ResultSet rs1 = select1.executeQuery();
			clusterModel.setRowCount(0);
			
			while(rs1.next()){
				Object[] row = {rs1.getString("asset_code"), rs1.getString("fixedAssetName"), rs1.getString("category_name"), rs1.getString("subcategory_name"), rs1.getDouble("age_Factor"), rs1.getDouble("usage_Factor"), rs1.getInt("clusterE"), rs1.getInt("clusterK"), rs1.getDate("cluster_date")};
				clusterModel.addRow(row);
			}
			rs1.close();
			select1.close();
			DBEKMEANS.conn.close();*/
			
			DBEKMEANS.TestConnection();
			
			String categoryList = "Select category_name from tbl_category where deleted = 0";
			PreparedStatement select2 =  DBEKMEANS.conn.prepareStatement(categoryList);
			
			ResultSet rs2 = select2.executeQuery();
			f_categoryField.addItem("");
			CB_category.addItem("");
			Filter.addItem("");
			dashFilterCB.addItem("");
			while(rs2.next()){
				String ctgry = rs2.getString("category_name");
				f_categoryField.addItem(ctgry);
				CB_category.addItem(ctgry);
				Filter.addItem(ctgry);
				dashFilterCB.addItem(ctgry);
				Object[] row = {ctgry};
				categoryModel.addRow(row);
				System.out.println(ctgry);
			}
			
			rs2.close();
			select2.close();
			DBEKMEANS.conn.close();
			
			DBEKMEANS.TestConnection();
			
			String categoryDataTable = "SELECT category_name, subcategory_name FROM tbl_category c join tbl_subcategory s on c.category_id = s.category_id";
			PreparedStatement select3 = DBEKMEANS.conn.prepareStatement(categoryDataTable);
			
			ResultSet rs3 = select3.executeQuery();
			k_subCategoryField.addItem("");
			sbFilter.addItem("");
			while(rs3.next()){
				String SubCategory = rs3.getString("subcategory_name");
				Object[] row = {rs3.getString("category_name"), SubCategory};
				subcategoryModel.addRow(row);
				k_subCategoryField.addItem(SubCategory);
			}
			
			rs3.close();
			select3.close();
			DBEKMEANS.conn.close();
			
			algorithm.addItem("");
			algorithm.addItem("K-MEANS");
			algorithm.addItem("ENHANCED_K-MEANS");
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		//Button Actions
		controll = new controller.ButtonListener();
		table = new controller.RowListener();
		CB = new controller.DropDownListener();
		focus = new controller.ChangeList();
		tab = new controller.ChangeListener();
		
		addButton.addActionListener(controll);
		clearButton.addActionListener(controll);
		searchButton.addActionListener(controll);
		deleteButton.addActionListener(controll);
		editButton.addActionListener(controll);
		updateButton.addActionListener(controll);
		clusterButton.addActionListener(controll);
		
		//utility
		c_Save.addActionListener(controll);
		c_Edit.addActionListener(controll);
		c_Update.addActionListener(controll);
		c_Delete.addActionListener(controll);
		
		fb_Save.addActionListener(controll);
		s_Save.addActionListener(controll);
		
		dataTable.getSelectionModel().addListSelectionListener(table);
		categoryTB.getSelectionModel().addListSelectionListener(table);
		
		f_categoryField.addItemListener(CB);
		f_categoryField.addFocusListener(focus);
		CB_category.addFocusListener(focus);
		f_assetCodeField.addFocusListener(focus);
		f_assetCodeField.addItemListener(CB);
		
		k_subCategoryField.addFocusListener(focus);
		Filter.addFocusListener(focus);
		filterButton.addActionListener(controll);
		
		system.addChangeListener(tab);
		indivButton.addActionListener(controll);
		listAsset.addFocusListener(focus);
		
		Filter.addItemListener(CB);
		salvageValueField.addFocusListener(focus);
		dashFilterCB.addFocusListener(focus);
		dashFilterButton.addActionListener(controll);
		//QUERY
		
		controller.QueryController query =  new controller.QueryController();
		query.level();
		query.net();
		query.salvage();
		
		//Dashboard
		controller.dashboardController dashboard = new controller.dashboardController();
		dashboard.kConsistency();
		dashboard.eConsistency();
		dashboard.avgStat();
		
		@SuppressWarnings("unused")
		controller.chartController chart = new controller.chartController();
	}

	@Override
	public void propertyChange(PropertyChangeEvent e) {
		// TODO Auto-generated method stub
		Object source = e.getSource();
        if (source == acqValueField) {
            acq = ((Number)acqValueField.getValue()).doubleValue();
        }
	}

}
