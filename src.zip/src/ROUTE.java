
import view.ASSETVIEW;
import view.WELCOMEVIEW;

public class ROUTE{
	public static void main(String[] args){
		
		
		ASSETVIEW.create();
		new WELCOMEVIEW();
	}

}
