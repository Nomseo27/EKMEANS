package eKMEANS;
import java.util.*;
public class TRY {
	public static void main(String[] args){
		EKMEANS example = new EKMEANS();
		boolean flag = false;
		int iteration = 1;
		
		example.initialize();
		// 1 get Inputs
		Scanner scan = new Scanner(System.in);
		System.out.print("Input x numbers:");
		// 2 get age Factor each
		for(int x=0; x<7; x++){
			example.ageFactor.add(scan.nextFloat());
		}
		// 3 get Inputs
		System.out.print("Input y numbers:");
		
		for(int x=0; x<7; x++){
			example.usageFactor.add(scan.nextFloat());
		}
		
		System.out.println();
		
		System.out.println("age factor: " + Arrays.toString(example.ageFactor.toArray()));
		System.out.println("usage factor: " + Arrays.toString(example.usageFactor.toArray()));
		
		System.out.println();
		
		System.out.println("mean of age factor: " + Arrays.toString(example.x.toArray()));
		System.out.println("mean of usage factor: " + Arrays.toString(example.y.toArray()));
		long start = System.currentTimeMillis();
		//15 get seed1
		example.getSeed1();
		//16 get seed 2
		example.getSeed2();
		
		//example.seed1 = new Float[2];
		//example.seed1[0] = new Float(1.0);
		//example.seed1[1] = new Float(4.0);
		//example.seed2 = new Float[2];
		//example.seed2[0] = new Float(4.0);
		//example.seed2[1] = new Float(1.0);
		
		
		
		System.out.println("seed1: " +  Arrays.toString(example.seed1) + "vehicle: " + example.point1);
		System.out.println("seed2: " + Arrays.toString(example.seed2) + "vehicle: " + example.point2);
		//17 get Distance 1
		example.setDistanceC1();
		//18 get Distance 2
		example.setDistanceC2();
		
		System.out.println("distance to C1: " + Arrays.toString(example.distanceC1.toArray()));
		System.out.println("distance to C2: " + Arrays.toString(example.distanceC2.toArray()));
		//19 get Clustering
		example.setCluster();
		
		System.out.println("clustering 1: " + Arrays.toString(example.group.toArray()));
	
		example.getAverage();
		
		System.out.println("average of cluster 1: " + Arrays.toString(example.seed1));
		System.out.println("average of cluster 2: " + Arrays.toString(example.seed2));
		
		do{
			example.distanceC1.clear();
			example.distanceC2.clear();
			
			example.setDistanceC1();
			example.setDistanceC2();
			
			
			example.oldGroup.clear();
			for(int i=0; i<example.group.size(); i++){
				example.oldGroup.add(example.group.get(i));
			}
			example.group.clear();
			example.setCluster();
			example.getAverage();
			iteration++;
			
			if(example.oldGroup.equals(example.group)){ 
				flag = false;
				
				System.out.println("Done");
				System.out.println("cluster of iteration " + iteration + ": " + Arrays.toString(example.group.toArray()));
				System.out.println("Iteration Done: " + iteration);
			}
			else{
				flag = true;
				System.out.println("cluster of iteration " + iteration + ": " + Arrays.toString(example.group.toArray()));
				System.out.println("Another Iteration");
			}
			
		}while(flag);
		//20 done
		long time = System.currentTimeMillis() - start;
		System.out.println(time);
		scan.close();
	}
}
