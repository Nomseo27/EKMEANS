package eKMEANS;

import java.util.Arrays;

import java.util.Random;
import java.util.Scanner;

public class kmeans {
	public static void main(String[] args){
		EKMEANS example = new EKMEANS();
		boolean flag = false;
		int iteration = 1;
		
		example.initialize();
		
		Scanner scan = new Scanner(System.in);
		System.out.print("Input x numbers:");
		
		for(int x=0; x<7; x++){
			example.ageFactor.add(scan.nextFloat());
		}
		
		System.out.print("Input y numbers:");
		
		for(int x=0; x<7; x++){
			example.usageFactor.add(scan.nextFloat());
		}
		
		System.out.println("age factor: " + Arrays.toString(example.ageFactor.toArray()));
		System.out.println("usage factor: " + Arrays.toString(example.usageFactor.toArray()));
		
		System.out.println();

		long start = System.currentTimeMillis();
		Random rand = new Random(); 
		int v1 = 0;
		v1 = rand.nextInt(6);
		int v2 = 0;
		do{
			v2 = rand.nextInt(6);
		}while(v1 == v2);
		
		/*int v1 = 0;
		int v2 = 0;
		
		System.out.print("Input seed 1 no:");
		v1 = scan.nextInt();
		System.out.print("Input seed 2 no:");
		v2 = scan.nextInt();*/
		
		
		example.seed1 = new Float[2];
		example.seed1[0] = new Float(example.ageFactor.get(v1));
		example.seed1[1] = new Float(example.usageFactor.get(v1));
		example.seed2 = new Float[2];
		example.seed2[0] = new Float(example.ageFactor.get(v2));
		example.seed2[1] = new Float(example.usageFactor.get(v2));
		
		
		
		System.out.println("seed1: " +  Arrays.toString(example.seed1) + "vehicle: " +(v1+1));
		System.out.println("seed2: " + Arrays.toString(example.seed2) + "vehicle: " + (v2+1));
		
		example.setDistanceC1();
		example.setDistanceC2();
		
		System.out.println("distance to C1: " + Arrays.toString(example.distanceC1.toArray()));
		System.out.println("distance to C2: " + Arrays.toString(example.distanceC2.toArray()));
		
		example.setCluster();
		
		System.out.println("clustering 1: " + Arrays.toString(example.group.toArray()));
		
		example.getAverage();
		
		System.out.println("average of cluster 1: " + Arrays.toString(example.seed1));
		System.out.println("average of cluster 2: " + Arrays.toString(example.seed2));
		
		do{
			example.distanceC1.clear();
			example.distanceC2.clear();
			
			example.setDistanceC1();
			example.setDistanceC2();
			
			System.out.println("distance to C1: " + Arrays.toString(example.distanceC1.toArray()));
			System.out.println("distance to C2: " + Arrays.toString(example.distanceC2.toArray()));
			
			example.oldGroup.clear();
			for(int i=0; i<example.group.size(); i++){
				example.oldGroup.add(example.group.get(i));
			}
			example.group.clear();
			System.out.println("average of cluster 1: " + Arrays.toString(example.seed1));
			System.out.println("average of cluster 2: " + Arrays.toString(example.seed2));
			example.setCluster();
			example.getAverage();
			iteration++;
			
			if(example.oldGroup.equals(example.group)){ 
				flag = false;
				
				System.out.println("Done");
				System.out.println("cluster of iteration " + iteration + ": " + Arrays.toString(example.group.toArray()));
				System.out.println("Iteration Done: " + iteration);
			}
			else{
				flag = true;
				System.out.println("cluster of iteration " + iteration + ": " + Arrays.toString(example.group.toArray()));
				System.out.println("Another Iteration");
			}
			
		}while(flag);
		long time = System.currentTimeMillis() - start;
		System.out.println(time);
		scan.close();
	}
}
