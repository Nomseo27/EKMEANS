package eKMEANS;
import java.util.*;
public class EKMEANS {
	//class attributes
	
	public List<String> asset_code;
	public List<Float> x;
	public List<Float> y;
	public List<Float> ageFactor;
	public List<Float> usageFactor;
	public List<Float> distanceC1;
	public List<Float> distanceC2;
	public List<Integer> group;
	public List<Integer> oldGroup;
	public Float[] seed1 = new Float[2];
	public Float[] seed2 = new Float[2];
	public Float[] centralMean = new Float[2];
	public Float[] lowestMean = new Float[2];
	public int point1;
	public int point2;
	public float highestPointX;
	public float highestPointY;
	public float lowestPointX;
	public float lowestPointY;
	public float sumY;
	public float sumX;
	int index;
	
	//class methods
	
	public void initialize(){
		x = new ArrayList<Float>();
		y = new ArrayList<Float>();
		asset_code = new ArrayList<String>();
		ageFactor = new ArrayList<Float>();
		usageFactor = new ArrayList<Float>();
		distanceC1 = new ArrayList<Float>();
		distanceC2 = new ArrayList<Float>();
		group = new ArrayList<Integer>();
		oldGroup = new ArrayList<Integer>();
	}//initialize()
	
	/*public float calculateRFX(float fltPoint, float fltHigh){
		return fltPoint/sumX;
	}//calculateMean 
	
	public float calculateRFY(float fltPoint, float fltHigh){
		return fltPoint/sumY;
	}//calculateMean
	
	public void setXRF(){
		for(int i=0; i<ageFactor.size(); i++){
			x.add(calculateRFX(ageFactor.get(i), highestPointX));
		}
	}//setXMean*/
	
	/*public float getHighestPoint(List<Float> set){
		float highest;
		highest = set.get(0);
		
		for(int i=1; i<set.size(); i++){
			if(highest < set.get(i)) highest = set.get(i);
		}
		
		return highest;
	}//getHighestPoint*/
	
	/*public float getSum(List<Float> set){
		float sum = 0;
		
		for(int i=0; i<set.size(); i++){
			sum = sum + set.get(i);
		}
		
		return sum;
	}//getHighestPoint*/
	
	/*public void setYRF(){
		for(int i=0; i<usageFactor.size(); i++){
			y.add(calculateRFY(usageFactor.get(i), highestPointY));
		}
	}//setYMean*/
	
	public void getSeed1(){
		index = 0;
		seed1[0] = new Float(ageFactor.get(0));
		seed1[1] = new Float(usageFactor.get(0));
		
		for(int i=1; i<ageFactor.size(); i++){
			if(seed1[0] > ageFactor.get(i) || seed1[1] > usageFactor.get(i)){
				seed1[0] = ageFactor.get(i);
				seed1[1] = usageFactor.get(i);
				index = i;
			}
				
		}
		
		System.out.println(seed1[0] + "-" + seed1[1]);
		
		/*int index = 0;
		
		for(int i=1; i<x.size(); i++){
			
				
				Float[] hold = new Float[2];
				hold[0] = new Float(x.get(i));
				hold[1] = new Float(y.get(i));
				
				float distanceOfCurr = getEuclideanDistance(1.0, 0, seed1);
				float distanceOfComp = getEuclideanDistance(1.0, 0, hold);
				
				System.out.println("[" + distanceOfCurr + ", " + distanceOfComp + "]");
				if(distanceOfCurr > distanceOfComp){
					
					seed1[0] = x.get(i);
					seed1[1] = y.get(i);
					index = i;
				}
			
		}
		
		seed1[0] = ageFactor.get(index);
		seed1[1] = usageFactor.get(index);
		
		point1 = index + 1;*/
		
		
		
		
	}//getSeed1

	public void getSeed2(){
		System.out.println(index);
		
		if(index != 0){
		seed2[0] = new Float(ageFactor.get(0));
		seed2[1] = new Float(usageFactor.get(0));
		System.out.println("!=0");
		}
		else {
			System.out.println("=0");
			for(int j=1; j<ageFactor.size(); j++){
				if(seed1[0] != ageFactor.get(j) && seed1[1] != usageFactor.get(j)){
					System.out.println(j);
					seed2[0] = ageFactor.get(j);
					seed2[1] = usageFactor.get(j);
					index = j;
					break;
				}
					
			}
		}
		
		for(int i=index; i<ageFactor.size(); i++){
			if(i != index){
				
			if(seed2[0] < ageFactor.get(i) || seed2[1] < usageFactor.get(i)){
				System.out.println(i);
				seed2[0] = ageFactor.get(i);
				seed2[1] = usageFactor.get(i);
				
			}
			}
				
		}
		
		/*int index = 0;
		
		for(int i=1; i<x.size(); i++){
			
				Float[] hold = new Float[2];
				hold[0] = new Float(x.get(i));
				hold[1] = new Float(y.get(i));
				
				float distanceOfCurr = getEuclideanDistance(1.0, 0, seed2);
				float distanceOfComp = getEuclideanDistance(1.0, 0, hold);
				
				System.out.println(i +": [" + distanceOfCurr + ", " + distanceOfComp + "]");
				if(distanceOfCurr < distanceOfComp){
					
					seed2[0] = x.get(i);
					seed2[1] = y.get(i);
					index = i;
				}
			
		}
		
		seed2[0] = ageFactor.get(index);
		seed2[1] = usageFactor.get(index);
		point2 = index + 1;*/
		
		
	}//getSeed2
	
	public float getEuclideanDistance(double d, double e, Float[] seed) {
		return (float) Math.sqrt(Math.pow(Math.abs(d-seed[0]), 2) + Math.pow(Math.abs(e-seed[1]), 2));
	}

	public float getEuclideanDistance(Float fltPointX, Float fltPointY, Float[] seed){
		return (float) Math.sqrt(Math.pow(Math.abs(fltPointX-seed[0]), 2) + Math.pow(Math.abs(fltPointY-seed[1]), 2));
	}//getEucleadianDistance
	
	public void setDistanceC1(){
		for(int i=0; i<ageFactor.size(); i++){
			distanceC1.add(getEuclideanDistance(ageFactor.get(i), usageFactor.get(i), seed1));
		}
	}
	
	public void setDistanceC2(){
		for(int i=0; i<ageFactor.size(); i++){
			distanceC2.add(getEuclideanDistance(ageFactor.get(i), usageFactor.get(i), seed2));
		}
	}
	
	public void setCluster(){
		for(int i=0; i<distanceC1.size(); i++){
			if(distanceC1.get(i) < distanceC2.get(i)){
				group.add(1);
			}
			else group.add(2);
		}
	}
	
	
	public void getAverage(){
		float sumX1 = 0, sumX2 = 0, sumY1 = 0, sumY2 = 0;
		int ctr1 = 0, ctr2 = 0;
		
		for(int i=0; i<group.size(); i++){
			if(group.get(i)==1){
				sumX1 = sumX1 + ageFactor.get(i);
				sumY1 = sumY1 + usageFactor.get(i);
				ctr1++;
			}
			else{
				sumX2 = sumX2 + ageFactor.get(i);
				sumY2 = sumY2 + usageFactor.get(i);
				ctr2++;
			}
		}
		
		seed1[0] = sumX1/ctr1;
		seed1[1] = sumY1/ctr1;
		
		seed2[0] = sumX2/ctr2;
		seed2[1] = sumY2/ctr2;
		
	}//getAverage
	
	
	/*public float getLowest(List<Float> set){
		float lowest;
		lowest = set.get(0);
			
		for(int i=1; i<set.size(); i++){
			if(lowest > set.get(i)) lowest = set.get(i);
		}
			
		return lowest;
	}// getLowest*/
	
	
	
	
}
