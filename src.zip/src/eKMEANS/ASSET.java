package eKMEANS;

import java.util.Date;

public class ASSET {
	
	String ID;
	String name;
	String type;
	float depRate;
	Date acqDate;
	float lifeTime;
	float ageFactor;
	float usageFactor;
	int groupFlag;
	
	//Constructor Methods
	
	ASSET(String strId, String strName, String strType, float fltDep, Date dtAcq, float fltLife){
		ID = strId;
		name = strName;
		type = strType;
		depRate = fltDep;
		acqDate = dtAcq;
		lifeTime = fltLife;
		
	}//ASSET constructor
	
	//get methods
	
	String getId(){
		return ID;
	}//getId
	
	public String getName(){
		return name;
	}//getName
	
	public String getType(){
		return type;
	}//getType
	
	public float getDepreciationRate(){
		return depRate;
	}//getDepreciationRate
	
	public Date getAcqDate(){
		return acqDate;
	}//getAcqDate
	
	public float getLifeTime(){
		return lifeTime;
	}//getLifeTime
	
	public float getAgeFactor(){
		return ageFactor;
	}//getAgeFactor
	
	public float getUsageFactor(){
		return usageFactor;
	}//getUsageFactor
	
	public int getGroupFlag(){
		return groupFlag;
	}//getGroupFlag
	
	//set Methods
	
	void setId(String strID){
		ID = strID;
	}//setID
	
	public void setName(String strName){
		name = strName;
	}//setType
	
	public void setType(String strType){
		type = strType;
	}//setType
	
	public void setDepreciationRate(float fltDepRate){
		depRate = fltDepRate;
	}//setDepreciationRate
	
	public void setAcqDate(Date dtAcqDate){
		acqDate = dtAcqDate;
	}//setAcqDate
	
	public void setLifeTime(float fltLifeTime){
		lifeTime = fltLifeTime;
	}//setLifeTime
	
	public void setAgeFactor(float fltAgeFactor){
		ageFactor = fltAgeFactor;
	}//setAgeFactor
	
	public void setUsageFactor(float fltUsageFactor){
		usageFactor = fltUsageFactor;
	}//setUsageFactor
	
	public void setGroupFlag(int flag){
		groupFlag = flag;
	}//setGroupFlag
	
}//AssetClass
